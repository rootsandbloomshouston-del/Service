import { Router } from 'express';
import {
  assignJobSchema,
  createJobNoteSchema,
  createJobPhotoSchema,
  createJobSchema,
  dispatchReminderSchema,
  scheduleJobSchema,
  updateJobStatusSchema,
  uploadJobPhotoSchema
} from '@shared/validators';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { JobRepository } from '../repositories/job.repository.js';
import { StorageService } from '../services/storage.service.js';
import { DispatchService } from '../services/dispatch.service.js';

const router = Router();
const repo = new JobRepository();
const storage = new StorageService();
const dispatch = new DispatchService();

router.use(requireAuth);

router.get('/', async (req, res) => res.json(await repo.list(req.user)));
router.get('/my/queue', requireRole('foreman'), async (req, res) => res.json(await repo.listForemanQueue(req.user!.id)));

router.get('/:id', async (req, res) => {
  const job = await repo.getById(req.params.id, req.user);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});

router.post('/', requireRole('owner'), validateBody(createJobSchema), async (req, res) => {
  res.status(201).json(await repo.create(req.body));
});

router.post('/:id/assign', requireRole('owner'), validateBody(assignJobSchema), async (req, res) => {
  const job = await repo.assign(req.params.id, req.body);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});

router.post('/:id/schedule', requireRole('owner'), validateBody(scheduleJobSchema), async (req, res) => {
  const job = await repo.schedule(req.params.id, req.body);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});

router.post('/:id/status', requireRole('owner', 'foreman'), validateBody(updateJobStatusSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.json(await repo.updateStatus(req.params.id, req.body));
});

router.post('/:id/notes', requireRole('owner', 'foreman'), validateBody(createJobNoteSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.status(201).json(await repo.addNote(req.params.id, req.user!.id, req.body));
});

router.post('/:id/photos', requireRole('owner', 'foreman'), validateBody(createJobPhotoSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.status(201).json(await repo.addPhoto(req.params.id, req.user!.id, req.body));
});

router.post('/:id/photos/upload', requireRole('owner', 'foreman'), validateBody(uploadJobPhotoSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  const stored = await storage.saveBase64Image(req.body);
  const photo = await repo.addPhoto(req.params.id, req.user!.id, {
    imageUrl: stored.publicUrl,
    storageKey: stored.storageKey,
    caption: req.body.caption
  });
  res.status(201).json(photo);
});

router.post('/:id/send-reminder', requireRole('owner', 'foreman'), validateBody(dispatchReminderSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  const result = await dispatch.sendJobReminder({
    jobId: req.params.id,
    destinationPhone: req.body.destinationPhone,
    message: req.body.message,
    scheduledFor: req.body.scheduledFor
  });
  res.json(result);
});

export default router;
