import { Router } from 'express';
import { routeBoardQuerySchema } from '@shared/validators';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { JobRepository } from '../repositories/job.repository.js';

const router = Router();
const repo = new JobRepository();

router.use(requireAuth);

router.get('/day', requireRole('owner', 'foreman'), async (req, res) => {
  const parsed = routeBoardQuerySchema.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ message: 'Invalid date query. Expected YYYY-MM-DD.' });
  }
  const board = await repo.getRouteBoard(parsed.data.date);
  res.json(board);
});

export default router;
