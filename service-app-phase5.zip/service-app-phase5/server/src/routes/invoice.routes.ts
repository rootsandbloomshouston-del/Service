import { Router } from 'express';
import { createInvoiceSchema, recordInvoicePaymentSchema } from '@shared/validators';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { InvoiceRepository } from '../repositories/invoice.repository.js';

const router = Router();
const repo = new InvoiceRepository();

router.use(requireAuth);

router.get('/', requireRole('owner', 'foreman'), async (_req, res) => {
  res.json(await repo.list());
});

router.get('/:id', requireRole('owner', 'foreman'), async (req, res) => {
  const invoice = await repo.getById(req.params.id);
  if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
  res.json(invoice);
});

router.post('/from-quote', requireRole('owner'), validateBody(createInvoiceSchema), async (req, res) => {
  const result = await repo.createFromQuote(req.body);
  if (!result) return res.status(404).json({ message: 'Source quote not found' });
  if ('existingInvoiceId' in result) return res.json(result);
  res.status(201).json(result);
});

router.post('/:id/payments', requireRole('owner'), validateBody(recordInvoicePaymentSchema), async (req, res) => {
  const invoice = await repo.recordPayment(req.params.id, req.body);
  if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
  res.json(invoice);
});

export default router;
