import cors from 'cors';
import express from 'express';
import path from 'node:path';
import authRoutes from './routes/auth.routes.js';
import customerRoutes from './routes/customer.routes.js';
import jobRoutes from './routes/job.routes.js';
import quoteRoutes from './routes/quote.routes.js';
import portalRoutes from './routes/portal.routes.js';
import scheduleRoutes from './routes/schedule.routes.js';
import invoiceRoutes from './routes/invoice.routes.js';
import { errorHandler } from './middleware/error-handler.js';
import { attachAuthenticatedUser } from './middleware/auth.js';

function harden(app: express.Express) {
  app.disable('x-powered-by');
  app.set('trust proxy', 1);
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    if (req.path.startsWith('/api/auth')) {
      res.setHeader('Cache-Control', 'no-store');
    }
    next();
  });
}

export function createApp() {
  const app = express();
  harden(app);
  app.use(cors({ origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173', credentials: true }));
  app.use(express.json({ limit: process.env.JSON_BODY_LIMIT ?? '12mb' }));
  app.use('/uploads', express.static(path.resolve(process.cwd(), 'uploads')));
  app.use(attachAuthenticatedUser);

  app.get('/api/health', (req, res) =>
    res.json({
      ok: true,
      service: 'service-app-api',
      env: process.env.NODE_ENV ?? 'development',
      uploadsEnabled: true,
      user: req.user ?? null
    })
  );

  app.use('/api/auth', authRoutes);
  app.use('/api/customers', customerRoutes);
  app.use('/api/jobs', jobRoutes);
  app.use('/api/quotes', quoteRoutes);
  app.use('/api/invoices', invoiceRoutes);
  app.use('/api/schedule', scheduleRoutes);
  app.use('/api/portal', portalRoutes);
  app.use(errorHandler);
  return app;
}
