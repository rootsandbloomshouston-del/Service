import { and, asc, desc, eq, gte, lt, or, isNull } from 'drizzle-orm';
import { db } from '../db/client.js';
import { customers, dispatchLogs, jobNotes, jobPhotos, jobs, users, type Job } from '../db/schema.js';
import type { AssignJobInput, CreateJobInput, CreateJobNoteInput, CreateJobPhotoInput, ScheduleJobInput, UpdateJobStatusInput } from '@shared/validators';

function buildDayBounds(dateString: string) {
  const start = new Date(`${dateString}T00:00:00.000Z`);
  const end = new Date(`${dateString}T23:59:59.999Z`);
  return { start, end };
}

export class JobRepository {
  async list(currentUser?: { id: string; role: string }) {
    const baseQuery = db.select({
      id: jobs.id,
      customerId: jobs.customerId,
      title: jobs.title,
      status: jobs.status,
      serviceAddress: jobs.serviceAddress,
      scheduledFor: jobs.scheduledFor,
      arrivalWindowStart: jobs.arrivalWindowStart,
      arrivalWindowEnd: jobs.arrivalWindowEnd,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      customerName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs).innerJoin(customers, eq(customers.id, jobs.customerId));

    const rows = currentUser?.role === 'foreman'
      ? await baseQuery.where(eq(jobs.assignedForemanUserId, currentUser.id)).orderBy(asc(jobs.scheduledFor), desc(jobs.createdAt))
      : await baseQuery.orderBy(asc(jobs.scheduledFor), desc(jobs.createdAt));

    return rows.map((row) => ({
      id: row.id,
      customerId: row.customerId,
      title: row.title,
      status: row.status,
      serviceAddress: row.serviceAddress,
      scheduledFor: row.scheduledFor,
      arrivalWindowStart: row.arrivalWindowStart,
      arrivalWindowEnd: row.arrivalWindowEnd,
      estimatedValueCents: row.estimatedValueCents,
      assignedForemanUserId: row.assignedForemanUserId,
      customerName: `${row.customerName} ${row.customerLastName}`
    }));
  }

  async getById(id: string, currentUser?: { id: string; role: string }) {
    const filters = [eq(jobs.id, id)];
    if (currentUser?.role === 'foreman') filters.push(eq(jobs.assignedForemanUserId, currentUser.id));

    const [job] = await db.select({
      id: jobs.id,
      customerId: jobs.customerId,
      sourceQuoteId: jobs.sourceQuoteId,
      title: jobs.title,
      description: jobs.description,
      serviceAddress: jobs.serviceAddress,
      status: jobs.status,
      scheduledFor: jobs.scheduledFor,
      arrivalWindowStart: jobs.arrivalWindowStart,
      arrivalWindowEnd: jobs.arrivalWindowEnd,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      customerName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs).innerJoin(customers, eq(customers.id, jobs.customerId)).where(and(...filters));

    if (!job) return undefined;

    const notes = await db.select({
      id: jobNotes.id,
      note: jobNotes.note,
      photoUrl: jobNotes.photoUrl,
      createdAt: jobNotes.createdAt,
      authorName: users.fullName
    }).from(jobNotes).leftJoin(users, eq(users.id, jobNotes.authorUserId)).where(eq(jobNotes.jobId, id)).orderBy(desc(jobNotes.createdAt));

    const photos = await db.select({
      id: jobPhotos.id,
      imageUrl: jobPhotos.imageUrl,
      caption: jobPhotos.caption,
      createdAt: jobPhotos.createdAt,
      uploadedByName: users.fullName
    }).from(jobPhotos).leftJoin(users, eq(users.id, jobPhotos.uploadedByUserId)).where(eq(jobPhotos.jobId, id)).orderBy(desc(jobPhotos.createdAt));

    const jobDispatches = await db.select({
      id: dispatchLogs.id,
      dispatchType: dispatchLogs.dispatchType,
      destination: dispatchLogs.destination,
      status: dispatchLogs.status,
      sentAt: dispatchLogs.sentAt,
      createdAt: dispatchLogs.createdAt
    }).from(dispatchLogs).where(eq(dispatchLogs.jobId, id)).orderBy(desc(dispatchLogs.createdAt));

    return {
      id: job.id,
      customerId: job.customerId,
      sourceQuoteId: job.sourceQuoteId,
      title: job.title,
      description: job.description,
      status: job.status,
      serviceAddress: job.serviceAddress,
      scheduledFor: job.scheduledFor,
      arrivalWindowStart: job.arrivalWindowStart,
      arrivalWindowEnd: job.arrivalWindowEnd,
      estimatedValueCents: job.estimatedValueCents,
      assignedForemanUserId: job.assignedForemanUserId,
      customerName: `${job.customerName} ${job.customerLastName}`,
      notes,
      photos,
      dispatchLogs: jobDispatches
    };
  }

  async create(input: CreateJobInput): Promise<Job> {
    const [job] = await db.insert(jobs).values({
      customerId: input.customerId,
      assignedForemanUserId: input.assignedForemanUserId ?? null,
      title: input.title,
      description: input.description || null,
      serviceAddress: input.serviceAddress,
      status: input.status,
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : null,
      arrivalWindowStart: input.arrivalWindowStart ? new Date(input.arrivalWindowStart) : null,
      arrivalWindowEnd: input.arrivalWindowEnd ? new Date(input.arrivalWindowEnd) : null,
      estimatedValueCents: input.estimatedValueCents ?? null
    }).returning();
    return job;
  }

  async createFromApprovedQuote(params: {
    customerId: string;
    quoteId: string;
    title: string;
    description?: string | null;
    serviceAddress: string;
    estimatedValueCents: number;
  }) {
    const [job] = await db.insert(jobs).values({
      customerId: params.customerId,
      sourceQuoteId: params.quoteId,
      title: params.title,
      description: params.description ?? null,
      serviceAddress: params.serviceAddress,
      status: 'approved',
      estimatedValueCents: params.estimatedValueCents
    }).returning();
    return job;
  }

  async assign(jobId: string, input: AssignJobInput) {
    const [job] = await db.update(jobs).set({ assignedForemanUserId: input.assignedForemanUserId, updatedAt: new Date() }).where(eq(jobs.id, jobId)).returning();
    return job;
  }

  async updateStatus(jobId: string, input: UpdateJobStatusInput) {
    const [job] = await db.update(jobs).set({
      status: input.status,
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : undefined,
      updatedAt: new Date()
    }).where(eq(jobs.id, jobId)).returning();
    return job;
  }

  async schedule(jobId: string, input: ScheduleJobInput) {
    const [job] = await db.update(jobs).set({
      status: input.status,
      scheduledFor: new Date(input.scheduledFor),
      arrivalWindowStart: input.arrivalWindowStart ? new Date(input.arrivalWindowStart) : null,
      arrivalWindowEnd: input.arrivalWindowEnd ? new Date(input.arrivalWindowEnd) : null,
      assignedForemanUserId: input.assignedForemanUserId ?? undefined,
      updatedAt: new Date()
    }).where(eq(jobs.id, jobId)).returning();
    return job;
  }

  async addNote(jobId: string, authorUserId: string, input: CreateJobNoteInput) {
    const [note] = await db.insert(jobNotes).values({ jobId, authorUserId, note: input.note, photoUrl: input.photoUrl || null }).returning();
    return note;
  }

  async addPhoto(jobId: string, uploadedByUserId: string, input: CreateJobPhotoInput & { storageKey?: string | null }) {
    const [photo] = await db.insert(jobPhotos).values({ jobId, uploadedByUserId, imageUrl: input.imageUrl, storageKey: input.storageKey ?? null, caption: input.caption || null }).returning();
    return photo;
  }

  async listForemanQueue(foremanUserId: string) {
    const rows = await db.select({
      id: jobs.id,
      title: jobs.title,
      status: jobs.status,
      serviceAddress: jobs.serviceAddress,
      scheduledFor: jobs.scheduledFor,
      arrivalWindowStart: jobs.arrivalWindowStart,
      arrivalWindowEnd: jobs.arrivalWindowEnd,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      customerName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs).innerJoin(customers, eq(customers.id, jobs.customerId)).where(eq(jobs.assignedForemanUserId, foremanUserId)).orderBy(asc(jobs.scheduledFor), desc(jobs.createdAt));

    return rows.map((row) => ({
      ...row,
      customerName: `${row.customerName} ${row.customerLastName}`
    }));
  }

  async getRouteBoard(dateString: string) {
    const { start, end } = buildDayBounds(dateString);
    const rows = await db.select({
      id: jobs.id,
      title: jobs.title,
      status: jobs.status,
      serviceAddress: jobs.serviceAddress,
      scheduledFor: jobs.scheduledFor,
      arrivalWindowStart: jobs.arrivalWindowStart,
      arrivalWindowEnd: jobs.arrivalWindowEnd,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      assignedForemanName: users.fullName,
      customerFirstName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs)
      .innerJoin(customers, eq(customers.id, jobs.customerId))
      .leftJoin(users, eq(users.id, jobs.assignedForemanUserId))
      .where(or(and(gte(jobs.scheduledFor, start), lt(jobs.scheduledFor, end)), isNull(jobs.scheduledFor)))
      .orderBy(asc(users.fullName), asc(jobs.arrivalWindowStart), asc(jobs.scheduledFor), asc(jobs.createdAt));

    const groups = new Map()
    for (const row of rows) {
      const key = row.assignedForemanUserId ?? 'unassigned';
      if (!groups.has(key)) {
        groups.set(key, {
          foremanUserId: row.assignedForemanUserId,
          foremanName: row.assignedForemanName ?? 'Unassigned',
          jobs: []
        })
      }
      groups.get(key).jobs.push({
        id: row.id,
        title: row.title,
        status: row.status,
        serviceAddress: row.serviceAddress,
        scheduledFor: row.scheduledFor,
        arrivalWindowStart: row.arrivalWindowStart,
        arrivalWindowEnd: row.arrivalWindowEnd,
        estimatedValueCents: row.estimatedValueCents,
        customerName: `${row.customerFirstName} ${row.customerLastName}`,
        assignedForemanUserId: row.assignedForemanUserId,
        assignedForemanName: row.assignedForemanName
      })
    }

    return Array.from(groups.values())
  }
}
