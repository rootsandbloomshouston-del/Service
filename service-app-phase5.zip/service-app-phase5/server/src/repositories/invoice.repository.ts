import { desc, eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { customers, invoiceLineItems, invoices, paymentEvents, quoteLineItems, quotes } from '../db/schema.js';
import type { CreateInvoiceInput, RecordInvoicePaymentInput } from '@shared/validators';

export class InvoiceRepository {
  async list() {
    const rows = await db.select({
      id: invoices.id,
      customerId: invoices.customerId,
      customerFirstName: customers.firstName,
      customerLastName: customers.lastName,
      status: invoices.status,
      totalCents: invoices.totalCents,
      balanceCents: invoices.balanceCents,
      dueDate: invoices.dueDate,
      paidAt: invoices.paidAt,
      jobId: invoices.jobId,
      sourceQuoteId: invoices.sourceQuoteId
    }).from(invoices).innerJoin(customers, eq(customers.id, invoices.customerId)).orderBy(desc(invoices.createdAt));

    return rows.map((row) => ({
      id: row.id,
      customerId: row.customerId,
      customerName: `${row.customerFirstName} ${row.customerLastName}`,
      status: row.status as 'draft' | 'sent' | 'partial' | 'paid' | 'void',
      totalCents: row.totalCents,
      balanceCents: row.balanceCents,
      dueDate: row.dueDate,
      paidAt: row.paidAt,
      jobId: row.jobId,
      sourceQuoteId: row.sourceQuoteId
    }));
  }

  async getById(id: string) {
    const [invoice] = await db.select({
      id: invoices.id,
      customerId: invoices.customerId,
      customerFirstName: customers.firstName,
      customerLastName: customers.lastName,
      status: invoices.status,
      subtotalCents: invoices.subtotalCents,
      taxCents: invoices.taxCents,
      totalCents: invoices.totalCents,
      balanceCents: invoices.balanceCents,
      dueDate: invoices.dueDate,
      paidAt: invoices.paidAt,
      notes: invoices.notes,
      jobId: invoices.jobId,
      sourceQuoteId: invoices.sourceQuoteId
    }).from(invoices).innerJoin(customers, eq(customers.id, invoices.customerId)).where(eq(invoices.id, id));

    if (!invoice) return undefined;
    const lineItems = await db.select().from(invoiceLineItems).where(eq(invoiceLineItems.invoiceId, id)).orderBy(invoiceLineItems.sortOrder);
    const payments = await db.select({
      id: paymentEvents.id,
      amountCents: paymentEvents.amountCents,
      method: paymentEvents.method,
      reference: paymentEvents.reference,
      receivedAt: paymentEvents.receivedAt,
      notes: paymentEvents.notes
    }).from(paymentEvents).where(eq(paymentEvents.invoiceId, id)).orderBy(desc(paymentEvents.receivedAt));

    return {
      id: invoice.id,
      customerId: invoice.customerId,
      customerName: `${invoice.customerFirstName} ${invoice.customerLastName}`,
      status: invoice.status as 'draft' | 'sent' | 'partial' | 'paid' | 'void',
      notes: invoice.notes,
      subtotalCents: invoice.subtotalCents,
      taxCents: invoice.taxCents,
      totalCents: invoice.totalCents,
      balanceCents: invoice.balanceCents,
      dueDate: invoice.dueDate,
      paidAt: invoice.paidAt,
      jobId: invoice.jobId,
      sourceQuoteId: invoice.sourceQuoteId,
      lineItems,
      payments: payments.map((payment) => ({
        ...payment,
        method: payment.method as 'cash' | 'check' | 'card' | 'ach' | 'other'
      }))
    };
  }

  async createFromQuote(input: CreateInvoiceInput) {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, input.sourceQuoteId));
    if (!quote) return undefined;

    const existing = await db.select({ id: invoices.id }).from(invoices).where(eq(invoices.sourceQuoteId, quote.id));
    if (existing[0]) return { existingInvoiceId: existing[0].id };

    const items = await db.select().from(quoteLineItems).where(eq(quoteLineItems.quoteId, quote.id)).orderBy(quoteLineItems.sortOrder);

    return db.transaction(async (tx) => {
      const [invoice] = await tx.insert(invoices).values({
        customerId: quote.customerId,
        jobId: quote.jobId ?? null,
        sourceQuoteId: quote.id,
        status: 'sent',
        subtotalCents: quote.subtotalCents,
        taxCents: quote.taxCents,
        totalCents: quote.totalCents,
        balanceCents: quote.totalCents,
        dueDate: input.dueDate ? new Date(input.dueDate) : null,
        notes: input.notes ?? quote.notes ?? null
      }).returning();

      if (items.length > 0) {
        await tx.insert(invoiceLineItems).values(items.map((item) => ({
          invoiceId: invoice.id,
          description: item.description,
          quantity: item.quantity,
          unitPriceCents: item.unitPriceCents,
          lineTotalCents: item.lineTotalCents,
          sortOrder: item.sortOrder
        })));
      }

      return { invoiceId: invoice.id };
    });
  }

  async recordPayment(invoiceId: string, input: RecordInvoicePaymentInput) {
    return db.transaction(async (tx) => {
      const [invoice] = await tx.select().from(invoices).where(eq(invoices.id, invoiceId));
      if (!invoice) return undefined;

      await tx.insert(paymentEvents).values({
        invoiceId,
        amountCents: input.amountCents,
        method: input.method,
        reference: input.reference ?? null,
        receivedAt: input.receivedAt ? new Date(input.receivedAt) : new Date(),
        notes: input.notes ?? null
      });

      const nextBalance = Math.max(0, invoice.balanceCents - input.amountCents);
      const status = nextBalance === 0 ? 'paid' : 'partial';

      const [updated] = await tx.update(invoices).set({
        balanceCents: nextBalance,
        status,
        paidAt: nextBalance === 0 ? new Date() : null,
        updatedAt: new Date()
      }).where(eq(invoices.id, invoiceId)).returning();

      return updated;
    });
  }
}
