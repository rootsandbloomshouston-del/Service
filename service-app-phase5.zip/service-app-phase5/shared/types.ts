export type Role = 'owner' | 'foreman' | 'customer';

export type AuthUser = {
  id: string;
  fullName: string;
  email: string;
  role: Role;
};

export type QuoteListItem = {
  id: string;
  status: string;
  totalCents: number;
  publicToken: string;
  paymentStatus: string;
  smsLastSentAt: string | null;
  customerApproved: boolean;
  jobId?: string | null;
};

export type JobListItem = {
  id: string;
  title: string;
  status: string;
  serviceAddress: string;
  scheduledFor: string | null;
  arrivalWindowStart: string | null;
  arrivalWindowEnd: string | null;
  estimatedValueCents: number | null;
  assignedForemanUserId: string | null;
  customerName?: string;
};

export type JobNoteItem = {
  id: string;
  note: string;
  photoUrl: string | null;
  createdAt: string;
  authorName: string | null;
};

export type JobPhotoItem = {
  id: string;
  caption: string | null;
  imageUrl: string;
  createdAt: string;
  uploadedByName: string | null;
};

export type DispatchLogItem = {
  id: string;
  dispatchType: string;
  destination: string;
  status: string;
  sentAt: string | null;
  createdAt: string;
};

export type JobDetail = JobListItem & {
  description: string | null;
  customerId: string;
  sourceQuoteId?: string | null;
  notes: JobNoteItem[];
  photos: JobPhotoItem[];
  dispatchLogs: DispatchLogItem[];
};

export type JobStatus = 'lead' | 'quoted' | 'approved' | 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

export type RouteBoardItem = {
  id: string;
  title: string;
  status: string;
  serviceAddress: string;
  scheduledFor: string | null;
  arrivalWindowStart: string | null;
  arrivalWindowEnd: string | null;
  estimatedValueCents: number | null;
  customerName: string;
  assignedForemanUserId: string | null;
  assignedForemanName: string | null;
};

export type RouteBoardGroup = {
  foremanUserId: string | null;
  foremanName: string;
  jobs: RouteBoardItem[];
};

export type InvoiceListItem = {
  id: string;
  customerName: string;
  status: 'draft' | 'sent' | 'partial' | 'paid' | 'void';
  totalCents: number;
  balanceCents: number;
  dueDate: string | null;
  paidAt: string | null;
  jobId: string | null;
  sourceQuoteId: string | null;
};

export type InvoicePaymentItem = {
  id: string;
  amountCents: number;
  method: 'cash' | 'check' | 'card' | 'ach' | 'other';
  reference: string | null;
  receivedAt: string;
  notes: string | null;
};

export type InvoiceDetail = InvoiceListItem & {
  customerId: string;
  notes: string | null;
  subtotalCents: number;
  taxCents: number;
  lineItems: Array<{
    id: string;
    description: string;
    quantity: string;
    unitPriceCents: number;
    lineTotalCents: number;
    sortOrder: number;
  }>;
  payments: InvoicePaymentItem[];
};
