import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';
import type { InvoiceDetail, InvoiceListItem, QuoteListItem } from '@shared/types';

const formatMoney = (cents: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);

export function InvoicesPage() {
  const [invoices, setInvoices] = useState<InvoiceListItem[]>([]);
  const [quotes, setQuotes] = useState<QuoteListItem[]>([]);
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceDetail | null>(null);
  const [sourceQuoteId, setSourceQuoteId] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [amountCents, setAmountCents] = useState('');
  const [method, setMethod] = useState<'cash' | 'check' | 'card' | 'ach' | 'other'>('card');
  const [reference, setReference] = useState('');
  const [message, setMessage] = useState<string | null>(null);

  async function load() {
    const [invoiceData, quoteData] = await Promise.all([
      apiFetch<InvoiceListItem[]>('/api/invoices'),
      apiFetch<QuoteListItem[]>('/api/quotes')
    ]);
    setInvoices(invoiceData);
    setQuotes(quoteData.filter((quote) => quote.customerApproved));
    if (!sourceQuoteId && quoteData[0]) setSourceQuoteId(quoteData[0].id);
  }

  async function loadInvoice(invoiceId: string) {
    const invoice = await apiFetch<InvoiceDetail>(`/api/invoices/${invoiceId}`);
    setSelectedInvoice(invoice);
  }

  useEffect(() => {
    load().catch(console.error);
  }, []);

  async function createInvoiceFromQuote() {
    const result = await apiFetch<{ invoiceId?: string; existingInvoiceId?: string }>('/api/invoices/from-quote', {
      method: 'POST',
      body: JSON.stringify({
        sourceQuoteId,
        dueDate: dueDate ? new Date(dueDate).toISOString() : undefined
      })
    });
    const invoiceId = result.invoiceId ?? result.existingInvoiceId;
    setMessage(result.existingInvoiceId ? 'Existing invoice already matched to that quote.' : 'Invoice created from approved quote.');
    await load();
    if (invoiceId) await loadInvoice(invoiceId);
  }

  async function recordPayment() {
    if (!selectedInvoice) return;
    await apiFetch(`/api/invoices/${selectedInvoice.id}/payments`, {
      method: 'POST',
      body: JSON.stringify({
        amountCents: Math.round(Number(amountCents) * 100),
        method,
        reference
      })
    });
    setMessage('Payment recorded and balance reconciled.');
    setAmountCents('');
    setReference('');
    await load();
    await loadInvoice(selectedInvoice.id);
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Invoices + payment reconciliation</h2>
        <p className="mt-1 text-sm text-slate-500">Convert approved quotes into invoices and track cash recovery cleanly.</p>
      </div>

      {message ? <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-700">{message}</div> : null}

      <div className="grid gap-6 xl:grid-cols-[400px_minmax(0,1fr)]">
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="text-lg font-semibold">Generate invoice from quote</h3>
            <div className="mt-4 space-y-4">
              <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={sourceQuoteId} onChange={(e) => setSourceQuoteId(e.target.value)}>
                <option value="">Select approved quote</option>
                {quotes.map((quote) => (
                  <option key={quote.id} value={quote.id}>{quote.id.slice(0, 8)} — {formatMoney(quote.totalCents)}</option>
                ))}
              </select>
              <label className="block text-sm font-medium text-slate-700">
                Due date
                <input className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2" type="datetime-local" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
              </label>
              <button type="button" className="w-full rounded-xl bg-slate-900 px-4 py-3 font-semibold text-white" disabled={!sourceQuoteId} onClick={() => createInvoiceFromQuote().catch(console.error)}>
                Create invoice
              </button>
            </div>
          </div>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-left text-slate-600">
                <tr>
                  <th className="px-4 py-3">Invoice</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Balance</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="cursor-pointer border-t border-slate-200 hover:bg-slate-50" onClick={() => loadInvoice(invoice.id).catch(console.error)}>
                    <td className="px-4 py-3">
                      <p className="font-medium">{invoice.id.slice(0, 8)}</p>
                      <p className="text-xs text-slate-500">{invoice.customerName}</p>
                    </td>
                    <td className="px-4 py-3">{invoice.status}</td>
                    <td className="px-4 py-3">{formatMoney(invoice.balanceCents)}</td>
                  </tr>
                ))}
                {invoices.length === 0 ? <tr><td className="px-4 py-6 text-slate-500" colSpan={3}>No invoices yet.</td></tr> : null}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          {!selectedInvoice ? <div className="text-sm text-slate-500">Select an invoice to inspect line items and record a payment.</div> : (
            <div className="space-y-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold">Invoice {selectedInvoice.id.slice(0, 8)}</h3>
                  <p className="text-sm text-slate-500">{selectedInvoice.customerName}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-500">Open balance</p>
                  <p className="text-2xl font-bold">{formatMoney(selectedInvoice.balanceCents)}</p>
                </div>
              </div>

              <div className="rounded-xl bg-slate-50 p-4">
                <div className="grid gap-3 md:grid-cols-3">
                  <div><p className="text-xs uppercase tracking-wide text-slate-500">Status</p><p className="mt-1 font-medium">{selectedInvoice.status}</p></div>
                  <div><p className="text-xs uppercase tracking-wide text-slate-500">Due</p><p className="mt-1 font-medium">{selectedInvoice.dueDate ? new Date(selectedInvoice.dueDate).toLocaleString() : 'Not set'}</p></div>
                  <div><p className="text-xs uppercase tracking-wide text-slate-500">Paid</p><p className="mt-1 font-medium">{selectedInvoice.paidAt ? new Date(selectedInvoice.paidAt).toLocaleString() : 'Open'}</p></div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold">Line items</h4>
                <div className="mt-3 space-y-2">
                  {selectedInvoice.lineItems.map((item) => (
                    <div key={item.id} className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-3">
                      <div>
                        <p className="font-medium">{item.description}</p>
                        <p className="text-xs text-slate-500">Qty {item.quantity} × {formatMoney(item.unitPriceCents)}</p>
                      </div>
                      <p className="font-semibold">{formatMoney(item.lineTotalCents)}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 flex items-center justify-end text-lg font-semibold">Total: {formatMoney(selectedInvoice.totalCents)}</div>
              </div>

              <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
                <div className="rounded-xl border border-slate-200 p-4">
                  <h4 className="font-semibold">Record payment</h4>
                  <div className="mt-3 space-y-3">
                    <input className="w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Amount in dollars" value={amountCents} onChange={(e) => setAmountCents(e.target.value)} />
                    <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={method} onChange={(e) => setMethod(e.target.value as typeof method)}>
                      <option value="card">Card</option>
                      <option value="cash">Cash</option>
                      <option value="check">Check</option>
                      <option value="ach">ACH</option>
                      <option value="other">Other</option>
                    </select>
                    <input className="w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Reference / check number" value={reference} onChange={(e) => setReference(e.target.value)} />
                    <button type="button" className="w-full rounded-xl bg-emerald-600 px-4 py-3 font-semibold text-white" disabled={!amountCents} onClick={() => recordPayment().catch(console.error)}>
                      Apply payment
                    </button>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 p-4">
                  <h4 className="font-semibold">Payment history</h4>
                  <div className="mt-3 space-y-3">
                    {selectedInvoice.payments.length === 0 ? <p className="text-sm text-slate-500">No payments recorded yet.</p> : selectedInvoice.payments.map((payment) => (
                      <article key={payment.id} className="rounded-xl border border-slate-200 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <p className="font-semibold">{formatMoney(payment.amountCents)}</p>
                          <span className="rounded-full bg-slate-100 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-700">{payment.method}</span>
                        </div>
                        <p className="mt-1 text-xs text-slate-500">{new Date(payment.receivedAt).toLocaleString()}</p>
                        {payment.reference ? <p className="mt-1 text-xs text-slate-500">Ref: {payment.reference}</p> : null}
                      </article>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
