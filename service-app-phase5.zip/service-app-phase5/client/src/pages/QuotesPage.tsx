import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../lib/api';
import type { QuoteListItem } from '@shared/types';

type Customer = { id: string; firstName: string; lastName: string; phone: string };
type QuoteDetail = { id: string; publicToken: string; totalCents: number; customer?: { phone?: string | null } | null };
type LineItem = { description: string; quantity: number; unitPriceCents: number };
const formatMoney = (cents: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);

export function QuotesPage() {
  const [quotes, setQuotes] = useState<QuoteListItem[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerId, setCustomerId] = useState('');
  const [notes, setNotes] = useState('');
  const [lineItems, setLineItems] = useState<LineItem[]>([{ description: '', quantity: 1, unitPriceCents: 0 }]);
  const [message, setMessage] = useState<string | null>(null);

  async function load() {
    const [quoteData, customerData] = await Promise.all([
      apiFetch<QuoteListItem[]>('/api/quotes'),
      apiFetch<Customer[]>('/api/customers')
    ]);
    setQuotes(quoteData);
    setCustomers(customerData);
    if (!customerId && customerData[0]) setCustomerId(customerData[0].id);
  }

  useEffect(() => { load().catch(console.error); }, []);
  const totalCents = useMemo(() => lineItems.reduce((sum, item) => sum + Math.round(item.quantity * item.unitPriceCents), 0), [lineItems]);

  async function createQuote() {
    await apiFetch('/api/quotes', { method: 'POST', body: JSON.stringify({ customerId, notes, lineItems }) });
    setNotes('');
    setLineItems([{ description: '', quantity: 1, unitPriceCents: 0 }]);
    await load();
  }

  async function sendSms(quoteId: string) {
    const detail = await apiFetch<QuoteDetail>(`/api/quotes/${quoteId}`);
    const phone = detail.customer?.phone;
    if (!phone) return setMessage('No customer phone on this quote.');
    const result = await apiFetch<{ portalUrl: string }>(`/api/quotes/${quoteId}/send-sms`, { method: 'POST', body: JSON.stringify({ phone }) });
    setMessage(`SMS sent. Portal: ${result.portalUrl}`);
    await load();
  }

  async function createPaymentLink(quoteId: string) {
    const result = await apiFetch<{ payment: { url: string } }>(`/api/quotes/${quoteId}/payment-link`, { method: 'POST', body: JSON.stringify({}) });
    setMessage(`Payment link ready: ${result.payment.url}`);
    await load();
  }

  async function convertToJob(quoteId: string) {
    const result = await apiFetch<{ job?: { id: string }, existing?: boolean, jobId?: string }>(`/api/quotes/${quoteId}/convert-to-job`, { method: 'POST' });
    const newJobId = result.job?.id ?? result.jobId;
    setMessage(newJobId ? `Job ready: ${newJobId}` : 'Quote already linked to a job.');
    await load();
  }

  async function createInvoice(quoteId: string) {
    const result = await apiFetch<{ invoiceId?: string; existingInvoiceId?: string }>('/api/invoices/from-quote', {
      method: 'POST',
      body: JSON.stringify({ sourceQuoteId: quoteId })
    });
    const invoiceId = result.invoiceId ?? result.existingInvoiceId;
    setMessage(invoiceId ? `Invoice ready: ${invoiceId}` : 'Invoice workflow complete.');
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Quotes</h2>
        <p className="mt-1 text-sm text-slate-500">Revenue workflow, approval conversion, and payment ops.</p>
      </div>
      <div className="grid gap-6 xl:grid-cols-[1.05fr_1.4fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold">Quick quote builder</h3>
          <div className="mt-4 space-y-4">
            <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
              {customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.firstName} {customer.lastName}</option>)}
            </select>
            {lineItems.map((item, index) => (
              <div key={index} className="grid gap-3 md:grid-cols-3">
                <input className="rounded-xl border border-slate-300 px-3 py-2" value={item.description} onChange={(e) => { const next = [...lineItems]; next[index].description = e.target.value; setLineItems(next); }} placeholder="Description" />
                <input type="number" className="rounded-xl border border-slate-300 px-3 py-2" value={item.quantity} onChange={(e) => { const next = [...lineItems]; next[index].quantity = Number(e.target.value); setLineItems(next); }} />
                <input type="number" className="rounded-xl border border-slate-300 px-3 py-2" value={item.unitPriceCents / 100} onChange={(e) => { const next = [...lineItems]; next[index].unitPriceCents = Math.round(Number(e.target.value) * 100); setLineItems(next); }} />
              </div>
            ))}
            <button type="button" className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium" onClick={() => setLineItems([...lineItems, { description: '', quantity: 1, unitPriceCents: 0 }])}>Add line item</button>
            <textarea className="min-h-24 w-full rounded-xl border border-slate-300 px-3 py-2" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Internal notes" />
            <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span className="text-sm text-slate-500">Total</span><span className="font-semibold">{formatMoney(totalCents)}</span></div>
            <button type="button" className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white" onClick={() => createQuote().catch(console.error)}>Create quote</button>
          </div>
        </div>
        <div className="space-y-4">
          {message ? <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-700">{message}</div> : null}
          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-left text-slate-600">
                <tr><th className="px-4 py-3">Quote</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Total</th><th className="px-4 py-3">Actions</th></tr>
              </thead>
              <tbody>
                {quotes.map((quote) => (
                  <tr key={quote.id} className="border-t border-slate-200">
                    <td className="px-4 py-3 font-medium">{quote.id.slice(0, 8)}</td>
                    <td className="px-4 py-3">{quote.status}</td>
                    <td className="px-4 py-3">{formatMoney(quote.totalCents)}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-2">
                        <button type="button" className="rounded-lg border border-slate-300 px-3 py-1.5" onClick={() => sendSms(quote.id).catch(console.error)}>Send SMS</button>
                        <button type="button" className="rounded-lg border border-slate-300 px-3 py-1.5" onClick={() => createPaymentLink(quote.id).catch(console.error)}>Payment link</button>
                        <button type="button" className="rounded-lg border border-slate-300 px-3 py-1.5 disabled:opacity-50" disabled={!!quote.jobId || !quote.customerApproved} onClick={() => convertToJob(quote.id).catch(console.error)}>{quote.jobId ? 'Job linked' : 'Convert to job'}</button>
                        <button type="button" className="rounded-lg border border-slate-300 px-3 py-1.5 disabled:opacity-50" disabled={!quote.customerApproved} onClick={() => createInvoice(quote.id).catch(console.error)}>Create invoice</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {quotes.length === 0 ? <tr><td className="px-4 py-6 text-slate-500" colSpan={4}>No quotes yet.</td></tr> : null}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
