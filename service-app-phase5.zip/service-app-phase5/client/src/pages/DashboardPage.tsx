import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function DashboardPage() {
  const { user } = useAuth();
  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Operational dashboard</h2>
        <p className="mt-1 text-sm text-slate-500">
          {user?.role === 'foreman'
            ? 'Your field queue, route board, updates, notes, and photo capture live here.'
            : 'Assign jobs, schedule crews, convert approved quotes into invoices, and close the cash loop.'}
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Authentication</p><h3 className="mt-2 text-lg font-semibold">Persisted session scaffold</h3><p className="mt-2 text-sm text-slate-600">Cookie-based auth backed by database sessions, with owner and foreman roles ready.</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Field operations</p><h3 className="mt-2 text-lg font-semibold">Dispatch scheduling</h3><p className="mt-2 text-sm text-slate-600">Route board by day, arrival windows, and foreman assignment are now part of the core workflow.</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Revenue</p><h3 className="mt-2 text-lg font-semibold">Invoice generation</h3><p className="mt-2 text-sm text-slate-600">Approved quotes can now be turned into invoices with payment reconciliation status.</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Deployment</p><h3 className="mt-2 text-lg font-semibold">Runtime hardening</h3><p className="mt-2 text-sm text-slate-600">Trust-proxy, secure headers, graceful shutdown, and request-size controls are layered in.</p></div>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="text-lg font-semibold">Next monetization step</h3>
        <p className="mt-2 text-sm text-slate-600">Phase 6 should be real calendar sync, invoice delivery, Stripe webhook reconciliation, and deployment to a hardened production target.</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Link to="/schedule" className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white">Open schedule</Link>
          <Link to="/invoices" className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Open invoices</Link>
          <Link to="/jobs" className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Open jobs</Link>
        </div>
      </div>
    </section>
  );
}
