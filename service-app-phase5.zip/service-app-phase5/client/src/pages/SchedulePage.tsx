import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../lib/api';
import type { JobListItem, RouteBoardGroup } from '@shared/types';

type Foreman = { id: string; fullName: string };
const formatMoney = (cents: number | null | undefined) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format((cents ?? 0) / 100);

function todayString() {
  return new Date().toISOString().slice(0, 10);
}

export function SchedulePage() {
  const [date, setDate] = useState(todayString());
  const [board, setBoard] = useState<RouteBoardGroup[]>([]);
  const [jobs, setJobs] = useState<JobListItem[]>([]);
  const [foremen, setForemen] = useState<Foreman[]>([]);
  const [jobId, setJobId] = useState('');
  const [scheduledFor, setScheduledFor] = useState('');
  const [arrivalWindowStart, setArrivalWindowStart] = useState('');
  const [arrivalWindowEnd, setArrivalWindowEnd] = useState('');
  const [assignedForemanUserId, setAssignedForemanUserId] = useState('');
  const [message, setMessage] = useState<string | null>(null);

  async function loadBoard(targetDate: string) {
    const [boardData, jobsData, foremanData] = await Promise.all([
      apiFetch<RouteBoardGroup[]>(`/api/schedule/day?date=${targetDate}`),
      apiFetch<JobListItem[]>('/api/jobs'),
      apiFetch<Foreman[]>('/api/auth/foremen')
    ]);
    setBoard(boardData);
    setJobs(jobsData);
    setForemen(foremanData);
    if (!jobId && jobsData[0]) setJobId(jobsData[0].id);
  }

  useEffect(() => {
    loadBoard(date).catch(console.error);
  }, [date]);

  const schedulableJobs = useMemo(
    () => jobs.filter((job) => job.status !== 'completed' && job.status !== 'cancelled'),
    [jobs]
  );

  async function scheduleJob() {
    await apiFetch(`/api/jobs/${jobId}/schedule`, {
      method: 'POST',
      body: JSON.stringify({
        scheduledFor: new Date(scheduledFor).toISOString(),
        arrivalWindowStart: arrivalWindowStart ? new Date(arrivalWindowStart).toISOString() : undefined,
        arrivalWindowEnd: arrivalWindowEnd ? new Date(arrivalWindowEnd).toISOString() : undefined,
        assignedForemanUserId: assignedForemanUserId || undefined,
        status: 'scheduled'
      })
    });
    setMessage('Job scheduled and route board refreshed.');
    await loadBoard(date);
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Schedule + route board</h2>
        <p className="mt-1 text-sm text-slate-500">Dispatch jobs by day, assign foremen, and tighten operational visibility.</p>
      </div>

      {message ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">{message}</div> : null}

      <div className="grid gap-6 xl:grid-cols-[420px_minmax(0,1fr)]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold">Schedule a job</h3>
          <div className="mt-4 space-y-4">
            <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={jobId} onChange={(e) => setJobId(e.target.value)}>
              {schedulableJobs.map((job) => (
                <option key={job.id} value={job.id}>{job.title} — {job.customerName}</option>
              ))}
            </select>
            <label className="block text-sm font-medium text-slate-700">
              Service date
              <input className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2" type="datetime-local" value={scheduledFor} onChange={(e) => setScheduledFor(e.target.value)} />
            </label>
            <div className="grid gap-3 md:grid-cols-2">
              <label className="block text-sm font-medium text-slate-700">
                Arrival window start
                <input className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2" type="datetime-local" value={arrivalWindowStart} onChange={(e) => setArrivalWindowStart(e.target.value)} />
              </label>
              <label className="block text-sm font-medium text-slate-700">
                Arrival window end
                <input className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2" type="datetime-local" value={arrivalWindowEnd} onChange={(e) => setArrivalWindowEnd(e.target.value)} />
              </label>
            </div>
            <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={assignedForemanUserId} onChange={(e) => setAssignedForemanUserId(e.target.value)}>
              <option value="">Unassigned</option>
              {foremen.map((foreman) => (
                <option key={foreman.id} value={foreman.id}>{foreman.fullName}</option>
              ))}
            </select>
            <button
              type="button"
              className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white disabled:opacity-50"
              disabled={!jobId || !scheduledFor}
              onClick={() => scheduleJob().catch(console.error)}
            >
              Save dispatch slot
            </button>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="text-lg font-semibold">Daily route board</h3>
                <p className="text-sm text-slate-500">Sorted by foreman and route timing.</p>
              </div>
              <input className="rounded-xl border border-slate-300 px-3 py-2" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
          </div>

          {board.map((group) => (
            <div key={group.foremanUserId ?? 'unassigned'} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="mb-4 flex items-center justify-between">
                <h4 className="text-lg font-semibold">{group.foremanName}</h4>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-700">{group.jobs.length} jobs</span>
              </div>
              <div className="space-y-3">
                {group.jobs.length === 0 ? <p className="text-sm text-slate-500">No jobs on this lane.</p> : group.jobs.map((job) => (
                  <article key={job.id} className="rounded-xl border border-slate-200 p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <h5 className="font-semibold text-slate-900">{job.title}</h5>
                        <p className="text-sm text-slate-600">{job.customerName}</p>
                        <p className="text-sm text-slate-500">{job.serviceAddress}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-slate-800">{formatMoney(job.estimatedValueCents)}</p>
                        <p className="text-xs uppercase tracking-wide text-slate-500">{job.status}</p>
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-600">
                      <span className="rounded-full bg-slate-100 px-3 py-1">Start: {job.scheduledFor ? new Date(job.scheduledFor).toLocaleString() : 'Unscheduled'}</span>
                      <span className="rounded-full bg-slate-100 px-3 py-1">Arrival: {job.arrivalWindowStart ? new Date(job.arrivalWindowStart).toLocaleTimeString() : '—'} {job.arrivalWindowEnd ? `to ${new Date(job.arrivalWindowEnd).toLocaleTimeString()}` : ''}</span>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
