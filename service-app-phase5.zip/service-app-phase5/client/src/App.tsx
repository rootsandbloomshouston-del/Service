import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { ProtectedRoute } from './components/ProtectedRoute';
import { AuthProvider } from './context/AuthContext';
import { CustomersPage } from './pages/CustomersPage';
import { DashboardPage } from './pages/DashboardPage';
import { JobsPage } from './pages/JobsPage';
import { InvoicesPage } from './pages/InvoicesPage';
import { LoginPage } from './pages/LoginPage';
import { PortalQuotePage } from './pages/PortalQuotePage';
import { QuotesPage } from './pages/QuotesPage';
import { SchedulePage } from './pages/SchedulePage';

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/portal/quotes/:token" element={<PortalQuotePage />} />
        <Route
          path="*"
          element={
            <ProtectedRoute roles={['owner', 'foreman']}>
              <Layout>
                <Routes>
                  <Route path="/" element={<DashboardPage />} />
                  <Route path="/customers" element={<CustomersPage />} />
                  <Route path="/jobs" element={<JobsPage />} />
                  <Route path="/quotes" element={<QuotesPage />} />
                  <Route path="/schedule" element={<SchedulePage />} />
                  <Route path="/invoices" element={<InvoicesPage />} />
                </Routes>
              </Layout>
            </ProtectedRoute>
          }
        />
      </Routes>
    </AuthProvider>
  );
}
