# Service App Scaffold — Phase 5

Phase 5 turns the scaffold into a tighter operations-and-cashflow system.

## Added in Phase 5
- Daily route board grouped by foreman
- Job scheduling endpoint with arrival windows
- Invoice generation directly from approved quotes
- Payment event ledger with balance reconciliation
- Runtime hardening for production prep
- Graceful shutdown and stricter runtime headers

## New database entities / fields
- `jobs.arrival_window_start`
- `jobs.arrival_window_end`
- `invoices`
- `invoice_line_items`
- `payment_events`

## New API surface

### Schedule
- `GET /api/schedule/day?date=YYYY-MM-DD`

### Jobs
- `POST /api/jobs/:id/schedule`

### Invoices
- `GET /api/invoices`
- `GET /api/invoices/:id`
- `POST /api/invoices/from-quote`
- `POST /api/invoices/:id/payments`

## UI added
- **Schedule** page for dispatch planning and route board review
- **Invoices** page for quote-to-invoice conversion and payment recording

## Deployment hardening included
- `trust proxy` enabled
- security headers added without extra dependencies
- `x-powered-by` disabled
- auth responses marked `no-store`
- configurable JSON body limit
- graceful shutdown hooks for `SIGINT` and `SIGTERM`

## Build order
1. Run a migration for the new invoice and scheduling fields
2. Seed or create at least one owner and one foreman
3. Approve a quote, then create an invoice from it
4. Schedule resulting jobs onto the route board
5. Record payments and verify balance transitions from `sent` → `partial` → `paid`

## Operational position
This is still optimized for rapid Replit deployment, not enterprise ceremony. That is the correct decision at this stage.
