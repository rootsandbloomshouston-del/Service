import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { CustomersPage } from './pages/CustomersPage';
import { DashboardPage } from './pages/DashboardPage';
import { JobsPage } from './pages/JobsPage';
import { QuotesPage } from './pages/QuotesPage';

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/customers" element={<CustomersPage />} />
        <Route path="/jobs" element={<JobsPage />} />
        <Route path="/quotes" element={<QuotesPage />} />
      </Routes>
    </Layout>
  );
}
