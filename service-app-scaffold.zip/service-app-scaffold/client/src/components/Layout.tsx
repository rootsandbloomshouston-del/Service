import type { PropsWithChildren } from 'react';
import { Link, useLocation } from 'react-router-dom';

const navItems = [
  { to: '/', label: 'Dashboard' },
  { to: '/customers', label: 'Customers' },
  { to: '/jobs', label: 'Jobs' },
  { to: '/quotes', label: 'Quotes' }
];

export function Layout({ children }: PropsWithChildren) {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-7xl flex-col md:flex-row">
        <aside className="w-full border-b border-slate-200 bg-white md:w-72 md:border-b-0 md:border-r">
          <div className="p-6">
            <h1 className="text-2xl font-bold">Service App</h1>
            <p className="mt-2 text-sm text-slate-500">Field ops, quotes, jobs, and customers.</p>
          </div>
          <nav className="flex gap-2 overflow-x-auto px-4 pb-4 md:flex-col md:px-6">
            {navItems.map((item) => {
              const active = location.pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`rounded-xl px-4 py-3 text-sm font-medium transition ${active ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'}`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>
        <main className="flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
