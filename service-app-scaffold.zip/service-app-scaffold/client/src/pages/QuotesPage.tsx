import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';

type Quote = {
  id: string;
  status: string;
  totalCents: number;
};

function formatMoney(cents: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
}

export function QuotesPage() {
  const [quotes, setQuotes] = useState<Quote[]>([]);

  useEffect(() => {
    apiFetch<Quote[]>('/api/quotes').then(setQuotes).catch(console.error);
  }, []);

  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold">Quotes</h2>
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-100 text-left text-slate-600">
            <tr>
              <th className="px-4 py-3">Quote</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Total</th>
            </tr>
          </thead>
          <tbody>
            {quotes.length === 0 ? (
              <tr><td className="px-4 py-4" colSpan={3}>No quotes yet.</td></tr>
            ) : quotes.map((quote) => (
              <tr key={quote.id} className="border-t border-slate-100">
                <td className="px-4 py-3 font-medium">{quote.id.slice(0, 8)}</td>
                <td className="px-4 py-3 uppercase">{quote.status}</td>
                <td className="px-4 py-3">{formatMoney(quote.totalCents)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
