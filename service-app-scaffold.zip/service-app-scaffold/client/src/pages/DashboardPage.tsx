const cards = [
  { label: 'Revenue Engine', value: 'Quotes + approvals' },
  { label: 'Field Ops', value: 'Jobs + notes' },
  { label: 'CRM', value: 'Customers' },
  { label: 'Next', value: 'Auth + portal + SMS' }
];

export function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Operational foundation</h2>
        <p className="mt-2 text-slate-600">Lean v1 spine for customers, jobs, and quotes.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="text-sm font-medium text-slate-500">{card.label}</div>
            <div className="mt-2 text-xl font-semibold text-slate-900">{card.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
