import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';

type Job = {
  id: string;
  title: string;
  status: string;
  serviceAddress: string;
};

export function JobsPage() {
  const [jobs, setJobs] = useState<Job[]>([]);

  useEffect(() => {
    apiFetch<Job[]>('/api/jobs').then(setJobs).catch(console.error);
  }, []);

  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold">Jobs</h2>
      <div className="grid gap-4 md:grid-cols-2">
        {jobs.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-5">No jobs yet.</div>
        ) : jobs.map((job) => (
          <article key={job.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-lg font-semibold">{job.title}</h3>
                <p className="mt-1 text-sm text-slate-500">{job.serviceAddress}</p>
              </div>
              <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-blue-700">{job.status}</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
