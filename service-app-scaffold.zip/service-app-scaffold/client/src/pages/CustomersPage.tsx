import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';

type Customer = {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  city: string;
  state: string;
};

export function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<Customer[]>('/api/customers').then(setCustomers).finally(() => setLoading(false));
  }, []);

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Customers</h2>
        <span className="rounded-full bg-slate-200 px-3 py-1 text-sm font-medium">{customers.length} total</span>
      </div>
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-100 text-left text-slate-600">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Phone</th>
              <th className="px-4 py-3">Location</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td className="px-4 py-4" colSpan={3}>Loading...</td></tr>
            ) : customers.length === 0 ? (
              <tr><td className="px-4 py-4" colSpan={3}>No customers yet.</td></tr>
            ) : customers.map((customer) => (
              <tr key={customer.id} className="border-t border-slate-100">
                <td className="px-4 py-3 font-medium">{customer.firstName} {customer.lastName}</td>
                <td className="px-4 py-3">{customer.phone}</td>
                <td className="px-4 py-3">{customer.city}, {customer.state}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
