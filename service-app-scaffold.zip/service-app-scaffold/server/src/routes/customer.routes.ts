import { Router } from 'express';
import { createCustomerSchema } from '@shared/validators';
import { validateBody } from '../middleware/validate.js';
import { CustomerRepository } from '../repositories/customer.repository.js';

const router = Router();
const repo = new CustomerRepository();

router.get('/', async (_req, res) => {
  res.json(await repo.list());
});

router.get('/:id', async (req, res) => {
  const customer = await repo.getById(req.params.id);
  if (!customer) return res.status(404).json({ message: 'Customer not found' });
  res.json(customer);
});

router.post('/', validateBody(createCustomerSchema), async (req, res) => {
  res.status(201).json(await repo.create(req.body));
});

export default router;
