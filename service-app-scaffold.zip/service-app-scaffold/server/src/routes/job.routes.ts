import { Router } from 'express';
import { createJobSchema } from '@shared/validators';
import { validateBody } from '../middleware/validate.js';
import { JobRepository } from '../repositories/job.repository.js';

const router = Router();
const repo = new JobRepository();

router.get('/', async (_req, res) => {
  res.json(await repo.list());
});

router.get('/:id', async (req, res) => {
  const job = await repo.getById(req.params.id);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});

router.post('/', validateBody(createJobSchema), async (req, res) => {
  res.status(201).json(await repo.create(req.body));
});

export default router;
