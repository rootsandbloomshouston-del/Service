import { Router } from 'express';
import { createQuoteSchema } from '@shared/validators';
import { validateBody } from '../middleware/validate.js';
import { QuoteRepository } from '../repositories/quote.repository.js';

const router = Router();
const repo = new QuoteRepository();

router.get('/', async (_req, res) => {
  res.json(await repo.list());
});

router.get('/:id', async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  res.json(quote);
});

router.post('/', validateBody(createQuoteSchema), async (req, res) => {
  res.status(201).json(await repo.create(req.body));
});

export default router;
