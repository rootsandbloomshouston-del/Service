import cors from 'cors';
import express from 'express';
import customerRoutes from './routes/customer.routes.js';
import jobRoutes from './routes/job.routes.js';
import quoteRoutes from './routes/quote.routes.js';
import { errorHandler } from './middleware/error-handler.js';

export function createApp() {
  const app = express();
  app.use(cors({ origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173' }));
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'service-app-api' });
  });

  app.use('/api/customers', customerRoutes);
  app.use('/api/jobs', jobRoutes);
  app.use('/api/quotes', quoteRoutes);
  app.use(errorHandler);
  return app;
}
