import { desc, eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { jobs, type Job } from '../db/schema.js';
import type { CreateJobInput } from '@shared/validators';

export class JobRepository {
  async list(): Promise<Job[]> {
    return db.select().from(jobs).orderBy(desc(jobs.createdAt));
  }

  async getById(id: string): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async create(input: CreateJobInput): Promise<Job> {
    const [job] = await db.insert(jobs).values({
      customerId: input.customerId,
      title: input.title,
      description: input.description || null,
      serviceAddress: input.serviceAddress,
      status: input.status,
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : null,
      estimatedValueCents: input.estimatedValueCents ?? null
    }).returning();
    return job;
  }
}
