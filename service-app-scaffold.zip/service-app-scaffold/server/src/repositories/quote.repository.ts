import { desc, eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { quoteLineItems, quotes, type Quote } from '../db/schema.js';
import type { CreateQuoteInput } from '@shared/validators';

function lineTotal(quantity: number, unitPriceCents: number): number {
  return Math.round(quantity * unitPriceCents);
}

export class QuoteRepository {
  async list(): Promise<Quote[]> {
    return db.select().from(quotes).orderBy(desc(quotes.createdAt));
  }

  async getById(id: string) {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, id));
    if (!quote) return undefined;
    const items = await db.select().from(quoteLineItems).where(eq(quoteLineItems.quoteId, id));
    return { ...quote, lineItems: items };
  }

  async create(input: CreateQuoteInput): Promise<{ quote: Quote }> {
    const subtotalCents = input.lineItems.reduce((sum, item) => sum + lineTotal(item.quantity, item.unitPriceCents), 0);
    const taxCents = 0;
    const totalCents = subtotalCents + taxCents;

    return db.transaction(async (tx) => {
      const [quote] = await tx.insert(quotes).values({
        customerId: input.customerId,
        jobId: input.jobId ?? null,
        status: input.status,
        subtotalCents,
        taxCents,
        totalCents,
        notes: input.notes ?? null,
        validUntil: input.validUntil ? new Date(input.validUntil) : null
      }).returning();

      await tx.insert(quoteLineItems).values(
        input.lineItems.map((item, index) => ({
          quoteId: quote.id,
          description: item.description,
          quantity: String(item.quantity),
          unitPriceCents: item.unitPriceCents,
          lineTotalCents: lineTotal(item.quantity, item.unitPriceCents),
          sortOrder: index
        }))
      );

      return { quote };
    });
  }
}
