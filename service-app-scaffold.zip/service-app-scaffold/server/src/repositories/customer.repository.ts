import { desc, eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { customers, type Customer } from '../db/schema.js';
import type { CreateCustomerInput } from '@shared/validators';

export class CustomerRepository {
  async list(): Promise<Customer[]> {
    return db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  async getById(id: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer;
  }

  async create(input: CreateCustomerInput): Promise<Customer> {
    const [customer] = await db.insert(customers).values({
      firstName: input.firstName,
      lastName: input.lastName,
      email: input.email || null,
      phone: input.phone,
      addressLine1: input.addressLine1,
      addressLine2: input.addressLine2 || null,
      city: input.city,
      state: input.state,
      postalCode: input.postalCode,
      notes: input.notes || null
    }).returning();
    return customer;
  }
}
