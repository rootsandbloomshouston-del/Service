# Service App Scaffold

Lean, production-oriented starter scaffold for a monetizable service business application.

## Stack
- React + Vite + TypeScript + Tailwind
- Express + TypeScript
- Drizzle ORM + PostgreSQL
- Zod validation

## Structure

```text
service-app-scaffold/
├── client/
│   └── src/
│       ├── components/
│       ├── lib/
│       ├── pages/
│       ├── App.tsx
│       ├── index.css
│       └── main.tsx
├── server/
│   └── src/
│       ├── db/
│       ├── middleware/
│       ├── repositories/
│       ├── routes/
│       ├── app.ts
│       └── index.ts
├── shared/
│   ├── types.ts
│   └── validators.ts
├── migrations/
├── drizzle.config.ts
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── tsconfig.client.json
├── tsconfig.server.json
└── vite.config.ts
```

## Database
- users
- customers
- jobs
- quotes
- quote_line_items
- job_notes

## API
- GET /api/health
- GET/POST /api/customers
- GET/POST /api/jobs
- GET/POST /api/quotes

## Start
```bash
cp .env.example .env
npm install
npm run db:generate
npm run db:push
npm run dev
```

## Next build sequence
1. Auth + role guards
2. Quote builder UI
3. Customer quote portal
4. Twilio SMS quote delivery
5. Stripe payment collection
