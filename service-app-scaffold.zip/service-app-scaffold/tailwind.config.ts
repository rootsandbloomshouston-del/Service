import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './client/src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#111827',
          accent: '#2563eb'
        }
      }
    }
  },
  plugins: []
} satisfies Config;
