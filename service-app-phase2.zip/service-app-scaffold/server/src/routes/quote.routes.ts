import { Router } from 'express';
import { createPaymentLinkSchema, createQuoteSchema, sendQuoteSmsSchema } from '@shared/validators';
import { validateBody } from '../middleware/validate.js';
import { requireRole } from '../middleware/auth.js';
import { QuoteRepository } from '../repositories/quote.repository.js';
import { TwilioService } from '../services/twilio.service.js';
import { StripeService } from '../services/stripe.service.js';

const router = Router();
const repo = new QuoteRepository();
const twilio = new TwilioService();
const stripe = new StripeService();

router.get('/', requireRole('owner', 'foreman'), async (_req, res) => {
  res.json(await repo.list());
});

router.get('/:id', requireRole('owner', 'foreman'), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  res.json(quote);
});

router.post('/', requireRole('owner', 'foreman'), validateBody(createQuoteSchema), async (req, res) => {
  res.status(201).json(await repo.create(req.body));
});

router.post('/:id/send-sms', requireRole('owner', 'foreman'), validateBody(sendQuoteSmsSchema), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });

  const portalBaseUrl = process.env.APP_BASE_URL ?? 'http://localhost:5173';
  const portalUrl = `${portalBaseUrl}/portal/quotes/${quote.publicToken}`;
  const smsResult = await twilio.sendQuoteSms({
    phone: req.body.phone,
    message: req.body.message,
    portalUrl,
    customerName: quote.customer ? `${quote.customer.firstName} ${quote.customer.lastName}` : undefined,
    amountDollars: `$${(quote.totalCents / 100).toFixed(2)}`
  });

  await repo.markSent(quote.id, req.body.phone);
  res.json({ ok: true, portalUrl, smsResult });
});

router.post('/:id/payment-link', requireRole('owner', 'foreman'), validateBody(createPaymentLinkSchema), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });

  const payment = await stripe.createPaymentLink({
    quoteId: quote.id,
    amountCents: quote.totalCents,
    successUrl: req.body.successUrl,
    cancelUrl: req.body.cancelUrl
  });

  await repo.attachPaymentLink(quote.id, payment.url);
  res.json({ ok: true, payment });
});

export default router;
