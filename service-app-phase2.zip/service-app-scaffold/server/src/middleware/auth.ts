import type { NextFunction, Request, Response } from 'express';
import type { AppRole } from '@shared/validators';

const validRoles: AppRole[] = ['owner', 'foreman', 'customer'];

export function attachDemoUser(req: Request, _res: Response, next: NextFunction) {
  const headerRole = String(req.header('x-demo-role') ?? 'owner') as AppRole;
  const role = validRoles.includes(headerRole) ? headerRole : 'owner';
  req.user = { id: 'demo-user', role };
  next();
}

export function requireRole(...roles: AppRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Forbidden' });
    }

    next();
  };
}
