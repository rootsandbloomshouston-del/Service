import cors from 'cors';
import express from 'express';
import customerRoutes from './routes/customer.routes.js';
import jobRoutes from './routes/job.routes.js';
import quoteRoutes from './routes/quote.routes.js';
import portalRoutes from './routes/portal.routes.js';
import { errorHandler } from './middleware/error-handler.js';
import { attachDemoUser } from './middleware/auth.js';

export function createApp() {
  const app = express();
  app.use(cors({ origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173' }));
  app.use(express.json());
  app.use(attachDemoUser);

  app.get('/api/health', (req, res) => {
    res.json({ ok: true, service: 'service-app-api', role: req.user?.role ?? 'owner' });
  });

  app.use('/api/customers', customerRoutes);
  app.use('/api/jobs', jobRoutes);
  app.use('/api/quotes', quoteRoutes);
  app.use('/api/portal', portalRoutes);
  app.use(errorHandler);
  return app;
}
