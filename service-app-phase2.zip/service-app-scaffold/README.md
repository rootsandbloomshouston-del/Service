# Service App Scaffold — Phase 2

This version moves the scaffold from passive CRUD into a revenue workflow.

## Added in Phase 2

- Quick quote builder UI
- Customer approval portal using public quote token
- SMS sending service abstraction (Twilio-ready, stubbed by default)
- Payment link service abstraction (Stripe-ready, stubbed by default)
- Demo role guard middleware for owner / foreman / customer

## API surface

### Protected admin routes
- `GET /api/quotes`
- `GET /api/quotes/:id`
- `POST /api/quotes`
- `POST /api/quotes/:id/send-sms`
- `POST /api/quotes/:id/payment-link`

### Public portal routes
- `GET /api/portal/quotes/:token`
- `POST /api/portal/quotes/:token/approve`

## Demo auth

This scaffold uses a simple demo role header so the UI can switch roles without building full auth first.

- Header: `x-demo-role`
- Values: `owner`, `foreman`, `customer`

The frontend stores this in localStorage through the role switcher.

## Why this sequencing is correct

This is the fastest path to monetizable behavior:

1. Build quote creation
2. Deliver quote by SMS
3. Let customer approve remotely
4. Generate payment link
5. Replace stubs with real Twilio and Stripe SDK calls later

That keeps the system shippable now without blocking on third-party credential plumbing.
