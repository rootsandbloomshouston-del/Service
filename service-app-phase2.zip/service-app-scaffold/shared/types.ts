export type Role = 'owner' | 'foreman' | 'customer';

export type QuoteListItem = {
  id: string;
  status: string;
  totalCents: number;
  publicToken: string;
  paymentStatus: string;
  smsLastSentAt: string | null;
  customerApproved: boolean;
};
