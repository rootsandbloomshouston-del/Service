import { z } from 'zod';

export const roleSchema = z.enum(['owner', 'foreman', 'customer']);

export const createCustomerSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email().optional().or(z.literal('')),
  phone: z.string().min(7),
  addressLine1: z.string().min(1),
  addressLine2: z.string().optional(),
  city: z.string().min(1),
  state: z.string().min(2),
  postalCode: z.string().min(5),
  notes: z.string().optional()
});

export const createJobSchema = z.object({
  customerId: z.string().uuid(),
  title: z.string().min(1),
  description: z.string().optional(),
  serviceAddress: z.string().min(1),
  status: z.enum(['lead', 'quoted', 'approved', 'scheduled', 'in_progress', 'completed', 'cancelled']).default('lead'),
  scheduledFor: z.string().datetime().optional(),
  estimatedValueCents: z.number().int().nonnegative().optional()
});

export const createQuoteLineItemSchema = z.object({
  description: z.string().min(1),
  quantity: z.number().positive(),
  unitPriceCents: z.number().int().nonnegative()
});

export const createQuoteSchema = z.object({
  customerId: z.string().uuid(),
  jobId: z.string().uuid().optional(),
  status: z.enum(['draft', 'sent', 'approved', 'rejected', 'expired']).default('draft'),
  validUntil: z.string().datetime().optional(),
  notes: z.string().optional(),
  lineItems: z.array(createQuoteLineItemSchema).min(1)
});

export const sendQuoteSmsSchema = z.object({
  phone: z.string().min(7),
  message: z.string().min(10).max(500).optional()
});

export const createPaymentLinkSchema = z.object({
  successUrl: z.string().url().optional(),
  cancelUrl: z.string().url().optional()
});

export type AppRole = z.infer<typeof roleSchema>;
export type CreateCustomerInput = z.infer<typeof createCustomerSchema>;
export type CreateJobInput = z.infer<typeof createJobSchema>;
export type CreateQuoteInput = z.infer<typeof createQuoteSchema>;
export type SendQuoteSmsInput = z.infer<typeof sendQuoteSmsSchema>;
export type CreatePaymentLinkInput = z.infer<typeof createPaymentLinkSchema>;
