import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { CustomersPage } from './pages/CustomersPage';
import { DashboardPage } from './pages/DashboardPage';
import { JobsPage } from './pages/JobsPage';
import { PortalQuotePage } from './pages/PortalQuotePage';
import { QuotesPage } from './pages/QuotesPage';

export default function App() {
  return (
    <Routes>
      <Route
        path="/portal/quotes/:token"
        element={<PortalQuotePage />}
      />
      <Route
        path="*"
        element={(
          <Layout>
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/customers" element={<CustomersPage />} />
              <Route path="/jobs" element={<JobsPage />} />
              <Route path="/quotes" element={<QuotesPage />} />
            </Routes>
          </Layout>
        )}
      />
    </Routes>
  );
}
