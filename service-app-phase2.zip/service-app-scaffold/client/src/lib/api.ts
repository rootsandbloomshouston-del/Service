export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const demoRole = window.localStorage.getItem('demo-role') ?? 'owner';
  const response = await fetch(path, {
    headers: {
      'Content-Type': 'application/json',
      'x-demo-role': demoRole,
      ...(init?.headers ?? {})
    },
    ...init
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `Request failed: ${response.status}`);
  }

  return response.json() as Promise<T>;
}
