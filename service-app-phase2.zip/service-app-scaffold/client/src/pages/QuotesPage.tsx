import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../lib/api';

type Customer = {
  id: string;
  firstName: string;
  lastName: string;
};

type Quote = {
  id: string;
  status: string;
  totalCents: number;
  publicToken: string;
  paymentStatus: string;
  smsLastSentAt: string | null;
  customerApproved: boolean;
};

type LineItem = {
  description: string;
  quantity: number;
  unitPriceCents: number;
};

function formatMoney(cents: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
}

export function QuotesPage() {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerId, setCustomerId] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sendResult, setSendResult] = useState<string | null>(null);
  const [paymentResult, setPaymentResult] = useState<string | null>(null);
  const [lineItems, setLineItems] = useState<LineItem[]>([
    { description: 'Base service', quantity: 1, unitPriceCents: 25000 },
    { description: 'Materials', quantity: 1, unitPriceCents: 5000 }
  ]);

  async function load() {
    const [quotesData, customersData] = await Promise.all([
      apiFetch<Quote[]>('/api/quotes'),
      apiFetch<Customer[]>('/api/customers')
    ]);
    setQuotes(quotesData);
    setCustomers(customersData);
    if (!customerId && customersData[0]) setCustomerId(customersData[0].id);
  }

  useEffect(() => {
    load().catch((err) => setError(err.message));
  }, []);

  const totalCents = useMemo(
    () => lineItems.reduce((sum, item) => sum + Math.round(item.quantity * item.unitPriceCents), 0),
    [lineItems]
  );

  async function createQuote() {
    setSubmitting(true);
    setError(null);
    try {
      await apiFetch('/api/quotes', {
        method: 'POST',
        body: JSON.stringify({
          customerId,
          notes,
          lineItems
        })
      });
      setNotes('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create quote');
    } finally {
      setSubmitting(false);
    }
  }

  async function sendSms(quote: Quote) {
    setSendResult(null);
    const customer = customers.find((item) => item.id === customerId) ?? customers[0];
    if (!customer) return;

    const details = await apiFetch<{ customer?: { phone?: string } }>(`/api/quotes/${quote.id}`);
    const phone = details.customer?.phone;
    if (!phone) {
      setSendResult('No phone number found on customer.');
      return;
    }

    const result = await apiFetch<{ portalUrl: string }>(`/api/quotes/${quote.id}/send-sms`, {
      method: 'POST',
      body: JSON.stringify({ phone })
    });

    setSendResult(`SMS queued. Portal: ${result.portalUrl}`);
    await load();
  }

  async function createPaymentLink(quote: Quote) {
    const result = await apiFetch<{ payment: { url: string } }>(`/api/quotes/${quote.id}/payment-link`, {
      method: 'POST',
      body: JSON.stringify({})
    });
    setPaymentResult(`Payment link ready: ${result.payment.url}`);
    await load();
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Quotes</h2>
        <p className="mt-1 text-sm text-slate-500">Create a quote, send it by SMS, and generate a payment link.</p>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.1fr_1.4fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-lg font-semibold">Quick quote builder</h3>
          <div className="mt-4 space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">Customer</label>
              <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
                {customers.map((customer) => (
                  <option key={customer.id} value={customer.id}>{customer.firstName} {customer.lastName}</option>
                ))}
              </select>
            </div>

            {lineItems.map((item, index) => (
              <div key={index} className="grid gap-3 rounded-xl border border-slate-200 p-3 md:grid-cols-3">
                <input
                  className="rounded-lg border border-slate-300 px-3 py-2"
                  value={item.description}
                  onChange={(e) => {
                    const next = [...lineItems];
                    next[index].description = e.target.value;
                    setLineItems(next);
                  }}
                  placeholder="Description"
                />
                <input
                  type="number"
                  className="rounded-lg border border-slate-300 px-3 py-2"
                  value={item.quantity}
                  onChange={(e) => {
                    const next = [...lineItems];
                    next[index].quantity = Number(e.target.value);
                    setLineItems(next);
                  }}
                  placeholder="Qty"
                />
                <input
                  type="number"
                  className="rounded-lg border border-slate-300 px-3 py-2"
                  value={item.unitPriceCents / 100}
                  onChange={(e) => {
                    const next = [...lineItems];
                    next[index].unitPriceCents = Math.round(Number(e.target.value) * 100);
                    setLineItems(next);
                  }}
                  placeholder="Unit price"
                />
              </div>
            ))}

            <button
              type="button"
              className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-medium text-slate-700"
              onClick={() => setLineItems([...lineItems, { description: '', quantity: 1, unitPriceCents: 0 }])}
            >
              Add line item
            </button>

            <textarea
              className="min-h-24 w-full rounded-xl border border-slate-300 px-3 py-2"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Internal quote notes"
            />

            <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3">
              <span className="text-sm font-medium text-slate-500">Total</span>
              <span className="text-lg font-semibold text-slate-900">{formatMoney(totalCents)}</span>
            </div>

            <button
              type="button"
              disabled={submitting || !customerId}
              onClick={createQuote}
              className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white disabled:opacity-50"
            >
              {submitting ? 'Creating...' : 'Create quote'}
            </button>

            {error ? <p className="text-sm text-red-600">{error}</p> : null}
          </div>
        </div>

        <div className="space-y-4">
          {sendResult ? <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">{sendResult}</div> : null}
          {paymentResult ? <div className="rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-700">{paymentResult}</div> : null}

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-left text-slate-600">
                <tr>
                  <th className="px-4 py-3">Quote</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Total</th>
                  <th className="px-4 py-3">Portal</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {quotes.length === 0 ? (
                  <tr><td className="px-4 py-4" colSpan={5}>No quotes yet.</td></tr>
                ) : quotes.map((quote) => (
                  <tr key={quote.id} className="border-t border-slate-100 align-top">
                    <td className="px-4 py-3 font-medium">{quote.id.slice(0, 8)}</td>
                    <td className="px-4 py-3">
                      <div className="uppercase">{quote.status}</div>
                      <div className="text-xs text-slate-500">{quote.customerApproved ? 'Approved' : 'Awaiting approval'}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div>{formatMoney(quote.totalCents)}</div>
                      <div className="text-xs text-slate-500">Payment: {quote.paymentStatus}</div>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-600">/portal/quotes/{quote.publicToken}</td>
                    <td className="space-y-2 px-4 py-3">
                      <button className="block rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white" onClick={() => sendSms(quote)}>Send SMS</button>
                      <button className="block rounded-lg bg-blue-600 px-3 py-2 text-xs font-semibold text-white" onClick={() => createPaymentLink(quote)}>Payment link</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
