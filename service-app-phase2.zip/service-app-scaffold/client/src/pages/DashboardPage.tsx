const cards = [
  { label: 'Revenue Engine', value: 'Quote builder + approval portal' },
  { label: 'Delivery', value: 'SMS send scaffolding' },
  { label: 'Payments', value: 'Stripe-ready link generation' },
  { label: 'Roles', value: 'Owner / Foreman / Customer demo guards' }
];

export function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Phase 2: revenue engine</h2>
        <p className="mt-2 text-slate-600">This layer turns quotes into a closable workflow instead of a static record.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="text-sm font-medium text-slate-500">{card.label}</div>
            <div className="mt-2 text-xl font-semibold text-slate-900">{card.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
