import type { AppRole } from '@shared/validators';

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        fullName: string;
        email: string;
        role: AppRole;
      };
    }
  }
}

export {};
