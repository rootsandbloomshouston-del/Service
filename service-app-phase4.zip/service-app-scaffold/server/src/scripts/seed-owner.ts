import 'dotenv/config';
import { UserRepository } from '../repositories/user.repository.js';
import { hashPassword } from '../utils/password.js';

async function main() {
  const users = new UserRepository();
  const email = process.env.SEED_OWNER_EMAIL ?? 'owner@example.com';
  const password = process.env.SEED_OWNER_PASSWORD ?? 'ChangeMe123!';
  const fullName = process.env.SEED_OWNER_NAME ?? 'Owner User';

  const existing = await users.findByEmail(email);
  if (existing) {
    console.log(`Owner already exists for ${email}`);
    return;
  }

  const user = await users.create({ fullName, email, password, role: 'owner', passwordHash: hashPassword(password) });
  console.log(`Created owner user ${user.email}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
