import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const SCRYPT_KEYLEN = 64;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const derivedKey = scryptSync(password, salt, SCRYPT_KEYLEN).toString('hex');
  return `${salt}:${derivedKey}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, storedKeyHex] = storedHash.split(':');
  if (!salt || !storedKeyHex) return false;
  const derivedKey = scryptSync(password, salt, SCRYPT_KEYLEN);
  const storedKey = Buffer.from(storedKeyHex, 'hex');
  if (storedKey.length !== derivedKey.length) return false;
  return timingSafeEqual(storedKey, derivedKey);
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}
