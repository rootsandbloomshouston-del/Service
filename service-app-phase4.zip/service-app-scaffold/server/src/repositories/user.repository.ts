import { eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { users, type User } from '../db/schema.js';
import type { RegisterInput } from '@shared/validators';

export class UserRepository {
  async listForemen(): Promise<Array<Pick<User, 'id' | 'fullName' | 'email' | 'role'>>> {
    return db.select({ id: users.id, fullName: users.fullName, email: users.email, role: users.role }).from(users).where(eq(users.role, 'foreman'));
  }

  async findByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase()));
    return user;
  }

  async create(input: RegisterInput & { passwordHash: string }): Promise<User> {
    const [user] = await db.insert(users).values({
      fullName: input.fullName,
      email: input.email.toLowerCase(),
      passwordHash: input.passwordHash,
      role: input.role
    }).returning();
    return user;
  }
}
