import { db } from '../db/client.js';
import { dispatchLogs } from '../db/schema.js';

export class DispatchRepository {
  async createLog(input: {
    jobId?: string | null;
    quoteId?: string | null;
    dispatchType: string;
    destination: string;
    body: string;
    providerMessageId?: string | null;
    status: string;
    sentAt?: Date | null;
  }) {
    const [row] = await db.insert(dispatchLogs).values({
      jobId: input.jobId ?? null,
      quoteId: input.quoteId ?? null,
      channel: 'sms',
      dispatchType: input.dispatchType,
      destination: input.destination,
      body: input.body,
      providerMessageId: input.providerMessageId ?? null,
      status: input.status,
      sentAt: input.sentAt ?? null
    }).returning();
    return row;
  }
}
