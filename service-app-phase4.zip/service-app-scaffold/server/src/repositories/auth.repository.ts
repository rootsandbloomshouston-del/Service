import { and, eq, gt } from 'drizzle-orm';
import { db } from '../db/client.js';
import { authSessions, users } from '../db/schema.js';

export class AuthRepository {
  async createSession(userId: string, tokenHash: string, expiresAt: Date) {
    const [session] = await db.insert(authSessions).values({ userId, tokenHash, expiresAt }).returning();
    return session;
  }

  async getUserByTokenHash(tokenHash: string) {
    const [result] = await db.select({
      sessionId: authSessions.id,
      userId: users.id,
      fullName: users.fullName,
      email: users.email,
      role: users.role
    }).from(authSessions).innerJoin(users, eq(users.id, authSessions.userId)).where(and(eq(authSessions.tokenHash, tokenHash), gt(authSessions.expiresAt, new Date())));
    return result;
  }

  async touchSession(sessionId: string) {
    await db.update(authSessions).set({ lastSeenAt: new Date() }).where(eq(authSessions.id, sessionId));
  }

  async deleteByTokenHash(tokenHash: string) {
    await db.delete(authSessions).where(eq(authSessions.tokenHash, tokenHash));
  }
}
