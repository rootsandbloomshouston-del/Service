import { desc, eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { customers, quoteLineItems, quotes, type Quote } from '../db/schema.js';
import type { CreateQuoteInput } from '@shared/validators';

function lineTotal(quantity: number, unitPriceCents: number): number {
  return Math.round(quantity * unitPriceCents);
}

function formatCustomerName(customer?: { firstName: string; lastName: string } | undefined) {
  return customer ? `${customer.firstName} ${customer.lastName}` : undefined;
}

export class QuoteRepository {
  async list() {
    return db.select({
      id: quotes.id,
      status: quotes.status,
      totalCents: quotes.totalCents,
      publicToken: quotes.publicToken,
      paymentStatus: quotes.paymentStatus,
      smsLastSentAt: quotes.smsLastSentAt,
      customerApproved: quotes.customerApproved,
      jobId: quotes.jobId
    }).from(quotes).orderBy(desc(quotes.createdAt));
  }

  async getById(id: string) {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, id));
    if (!quote) return undefined;
    const items = await db.select().from(quoteLineItems).where(eq(quoteLineItems.quoteId, id));
    const [customer] = await db.select({
      id: customers.id,
      firstName: customers.firstName,
      lastName: customers.lastName,
      email: customers.email,
      phone: customers.phone,
      addressLine1: customers.addressLine1,
      addressLine2: customers.addressLine2,
      city: customers.city,
      state: customers.state,
      postalCode: customers.postalCode
    }).from(customers).where(eq(customers.id, quote.customerId));
    return { ...quote, lineItems: items, customer };
  }

  async getByPublicToken(publicToken: string) {
    const [quote] = await db.select().from(quotes).where(eq(quotes.publicToken, publicToken));
    if (!quote) return undefined;
    const items = await db.select().from(quoteLineItems).where(eq(quoteLineItems.quoteId, quote.id));
    const [customer] = await db.select({
      id: customers.id,
      firstName: customers.firstName,
      lastName: customers.lastName,
      email: customers.email,
      phone: customers.phone,
      addressLine1: customers.addressLine1,
      addressLine2: customers.addressLine2,
      city: customers.city,
      state: customers.state,
      postalCode: customers.postalCode
    }).from(customers).where(eq(customers.id, quote.customerId));
    return {
      ...quote,
      lineItems: items,
      customer,
      customerName: formatCustomerName(customer)
    };
  }

  async create(input: CreateQuoteInput): Promise<{ quote: Quote }> {
    const subtotalCents = input.lineItems.reduce((sum, item) => sum + lineTotal(item.quantity, item.unitPriceCents), 0);
    const taxCents = 0;
    const totalCents = subtotalCents + taxCents;

    return db.transaction(async (tx) => {
      const [quote] = await tx.insert(quotes).values({
        customerId: input.customerId,
        jobId: input.jobId ?? null,
        status: input.status,
        subtotalCents,
        taxCents,
        totalCents,
        notes: input.notes ?? null,
        validUntil: input.validUntil ? new Date(input.validUntil) : null
      }).returning();

      await tx.insert(quoteLineItems).values(
        input.lineItems.map((item, index) => ({
          quoteId: quote.id,
          description: item.description,
          quantity: String(item.quantity),
          unitPriceCents: item.unitPriceCents,
          lineTotalCents: lineTotal(item.quantity, item.unitPriceCents),
          sortOrder: index
        }))
      );

      return { quote };
    });
  }

  async markSmsSent(id: string, phone: string) {
    const [updated] = await db.update(quotes).set({
      status: 'sent',
      sentAt: new Date(),
      smsLastSentAt: new Date(),
      smsLastSentTo: phone,
      updatedAt: new Date()
    }).where(eq(quotes.id, id)).returning();
    return updated;
  }

  async approveByPublicToken(publicToken: string) {
    const [updated] = await db.update(quotes).set({
      status: 'approved',
      customerApproved: true,
      approvedAt: new Date(),
      updatedAt: new Date()
    }).where(eq(quotes.publicToken, publicToken)).returning();
    return updated;
  }

  async attachPaymentLink(id: string, paymentLinkUrl: string) {
    const [updated] = await db.update(quotes).set({
      paymentLinkUrl,
      paymentStatus: 'pending',
      updatedAt: new Date()
    }).where(eq(quotes.id, id)).returning();
    return updated;
  }

  async attachJob(id: string, jobId: string) {
    const [updated] = await db.update(quotes).set({
      jobId,
      updatedAt: new Date()
    }).where(eq(quotes.id, id)).returning();
    return updated;
  }
}
