import type { NextFunction, Request, Response } from 'express';
import { hashToken } from '../utils/password.js';
import { AuthRepository } from '../repositories/auth.repository.js';
import type { AppRole } from '@shared/validators';

const authRepo = new AuthRepository();
const SESSION_COOKIE_NAME = 'service_app_session';

function parseCookieValue(cookieHeader: string | undefined, cookieName: string): string | undefined {
  if (!cookieHeader) return undefined;
  const parts = cookieHeader.split(';').map((value) => value.trim());
  const match = parts.find((part) => part.startsWith(`${cookieName}=`));
  if (!match) return undefined;
  return decodeURIComponent(match.slice(cookieName.length + 1));
}

export function setSessionCookie(res: Response, token: string) {
  const isProd = process.env.NODE_ENV === 'production';
  const maxAgeSeconds = 60 * 60 * 24 * 14;
  res.setHeader('Set-Cookie', `${SESSION_COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}${isProd ? '; Secure' : ''}`);
}

export function clearSessionCookie(res: Response) {
  const isProd = process.env.NODE_ENV === 'production';
  res.setHeader('Set-Cookie', `${SESSION_COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${isProd ? '; Secure' : ''}`);
}

export async function attachAuthenticatedUser(req: Request, _res: Response, next: NextFunction) {
  const rawToken = parseCookieValue(req.headers.cookie, SESSION_COOKIE_NAME);
  if (!rawToken) return next();
  const result = await authRepo.getUserByTokenHash(hashToken(rawToken));
  if (!result) return next();
  req.user = { id: result.userId, fullName: result.fullName, email: result.email, role: result.role as AppRole };
  await authRepo.touchSession(result.sessionId);
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
  next();
}

export function requireRole(...roles: AppRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ message: 'Forbidden' });
    next();
  };
}
