import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const allowedMimeToExt: Record<string, string> = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif'
};

export class StorageService {
  async saveBase64Image(input: { folder: string; filename: string; mimeType: string; dataBase64: string }) {
    const ext = allowedMimeToExt[input.mimeType] ?? path.extname(input.filename) || '.bin';
    const safeFolder = input.folder.replace(/[^a-zA-Z0-9/_-]/g, '');
    const uploadsRoot = path.resolve(process.cwd(), 'uploads', safeFolder);
    await mkdir(uploadsRoot, { recursive: true });
    const fileName = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}${ext}`;
    const fullPath = path.join(uploadsRoot, fileName);
    const buffer = Buffer.from(input.dataBase64, 'base64');
    await writeFile(fullPath, buffer);
    const relativeUrl = `/uploads/${safeFolder}/${fileName}`.replace(/\\/g, '/');
    return { storageKey: `${safeFolder}/${fileName}`, url: relativeUrl };
  }
}
