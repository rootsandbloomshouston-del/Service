import { TwilioService } from './twilio.service.js';
import { DispatchRepository } from '../repositories/dispatch.repository.js';

export class DispatchService {
  private twilio = new TwilioService();
  private repo = new DispatchRepository();

  async sendJobReminder(input: { jobId: string; destinationPhone: string; message: string }) {
    const sms = await this.twilio.sendQuoteLink({
      to: input.destinationPhone,
      message: input.message,
      portalUrl: ''
    });
    await this.repo.createLog({
      jobId: input.jobId,
      dispatchType: 'job_reminder',
      destination: input.destinationPhone,
      body: input.message,
      providerMessageId: sms.id ?? null,
      status: sms.provider === 'stub' ? 'stubbed' : 'sent',
      sentAt: new Date()
    });
    return sms;
  }

  async queueJobReminder(input: { jobId: string; destinationPhone: string; message: string }) {
    const log = await this.repo.createLog({
      jobId: input.jobId,
      dispatchType: 'job_reminder_scheduled',
      destination: input.destinationPhone,
      body: input.message,
      status: 'scheduled'
    });
    return log;
  }

  async recordQuoteSms(input: { quoteId: string; destinationPhone: string; body: string; providerMessageId?: string | null; provider: string }) {
    return this.repo.createLog({
      quoteId: input.quoteId,
      dispatchType: 'quote_sms',
      destination: input.destinationPhone,
      body: input.body,
      providerMessageId: input.providerMessageId ?? null,
      status: input.provider === 'stub' ? 'stubbed' : 'sent',
      sentAt: new Date()
    });
  }
}
