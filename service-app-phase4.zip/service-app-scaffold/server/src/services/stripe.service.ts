import crypto from 'node:crypto';

type CreatePaymentLinkArgs = {
  quoteId: string;
  amountCents: number;
  successUrl?: string;
  cancelUrl?: string;
};

export class StripeService {
  async createPaymentLink(args: CreatePaymentLinkArgs) {
    const baseUrl = process.env.APP_BASE_URL ?? 'http://localhost:5173';
    const successUrl = args.successUrl ?? `${baseUrl}/quotes?paid=1`;
    const cancelUrl = args.cancelUrl ?? `${baseUrl}/quotes?cancelled=1`;

    if (!process.env.STRIPE_SECRET_KEY) {
      const token = crypto.randomBytes(12).toString('hex');
      return {
        provider: 'stub',
        url: `${baseUrl}/mock-checkout/${args.quoteId}?token=${token}&amount=${args.amountCents}`,
        successUrl,
        cancelUrl
      };
    }

    return {
      provider: 'stripe',
      url: `${baseUrl}/stripe-checkout/${args.quoteId}`,
      successUrl,
      cancelUrl
    };
  }
}
