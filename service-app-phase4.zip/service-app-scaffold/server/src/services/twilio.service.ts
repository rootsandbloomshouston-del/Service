import type { SendQuoteSmsInput } from '@shared/validators';

type SendQuoteSmsArgs = SendQuoteSmsInput & {
  portalUrl: string;
  customerName?: string;
  amountDollars: string;
};

export class TwilioService {
  async sendQuoteSms(args: SendQuoteSmsArgs) {
    const body = args.message?.trim() || `Your quote is ready${args.customerName ? `, ${args.customerName}` : ''}. Review and approve here: ${args.portalUrl}. Total: ${args.amountDollars}`;

    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_FROM_PHONE) {
      return {
        provider: 'stub',
        status: 'simulated',
        to: args.phone,
        body
      };
    }

    return {
      provider: 'twilio',
      status: 'ready_for_sdk',
      to: args.phone,
      body
    };
  }
}
