import { randomBytes } from 'node:crypto';
import { Router } from 'express';
import { loginSchema, registerSchema } from '@shared/validators';
import { validateBody } from '../middleware/validate.js';
import { clearSessionCookie, requireAuth, requireRole, setSessionCookie } from '../middleware/auth.js';
import { UserRepository } from '../repositories/user.repository.js';
import { AuthRepository } from '../repositories/auth.repository.js';
import { hashPassword, hashToken, verifyPassword } from '../utils/password.js';

const router = Router();
const users = new UserRepository();
const auth = new AuthRepository();

router.get('/me', (req, res) => res.json({ user: req.user ?? null }));

router.post('/register', validateBody(registerSchema), async (req, res) => {
  const existing = await users.findByEmail(req.body.email);
  if (existing) return res.status(409).json({ message: 'Email already exists' });
  const user = await users.create({ ...req.body, passwordHash: hashPassword(req.body.password) });
  const rawToken = randomBytes(32).toString('hex');
  await auth.createSession(user.id, hashToken(rawToken), new Date(Date.now() + 1000 * 60 * 60 * 24 * 14));
  setSessionCookie(res, rawToken);
  res.status(201).json({ user: { id: user.id, fullName: user.fullName, email: user.email, role: user.role } });
});

router.post('/login', validateBody(loginSchema), async (req, res) => {
  const user = await users.findByEmail(req.body.email);
  if (!user || !verifyPassword(req.body.password, user.passwordHash)) return res.status(401).json({ message: 'Invalid email or password' });
  const rawToken = randomBytes(32).toString('hex');
  await auth.createSession(user.id, hashToken(rawToken), new Date(Date.now() + 1000 * 60 * 60 * 24 * 14));
  setSessionCookie(res, rawToken);
  res.json({ user: { id: user.id, fullName: user.fullName, email: user.email, role: user.role } });
});

router.post('/logout', requireAuth, async (req, res) => {
  const cookieHeader = req.headers.cookie ?? '';
  const match = cookieHeader.split(';').map((part) => part.trim()).find((part) => part.startsWith('service_app_session='));
  if (match) {
    const rawToken = decodeURIComponent(match.slice('service_app_session='.length));
    await auth.deleteByTokenHash(hashToken(rawToken));
  }
  clearSessionCookie(res);
  res.status(204).send();
});

router.get('/foremen', requireAuth, requireRole('owner'), async (_req, res) => res.json(await users.listForemen()));

export default router;
