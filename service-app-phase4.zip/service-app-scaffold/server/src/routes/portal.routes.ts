import { Router } from 'express';
import { QuoteRepository } from '../repositories/quote.repository.js';
import { JobRepository } from '../repositories/job.repository.js';

const router = Router();
const repo = new QuoteRepository();
const jobs = new JobRepository();

router.get('/quotes/:token', async (req, res) => {
  const quote = await repo.getByPublicToken(req.params.token);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  res.json(quote);
});

router.post('/quotes/:token/approve', async (req, res) => {
  const quote = await repo.getByPublicToken(req.params.token);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });

  const approved = await repo.approveByPublicToken(req.params.token);

  let createdJobId: string | null = quote.jobId ?? null;
  if (!quote.jobId) {
    const serviceAddress = [quote.customer?.addressLine1, quote.customer?.addressLine2, quote.customer?.city, quote.customer?.state, quote.customer?.postalCode]
      .filter(Boolean)
      .join(', ');
    const job = await jobs.createFromApprovedQuote({
      customerId: quote.customerId,
      quoteId: quote.id,
      title: `Approved Quote ${quote.id.slice(0, 8)}`,
      description: quote.notes ?? 'Auto-generated from approved customer approval.',
      serviceAddress,
      estimatedValueCents: quote.totalCents
    });
    await repo.attachJob(quote.id, job.id);
    createdJobId = job.id;
  }

  res.json({ ok: true, quote: approved, createdJobId });
});

export default router;
