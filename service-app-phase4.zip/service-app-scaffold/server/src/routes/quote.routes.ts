import { Router } from 'express';
import { createPaymentLinkSchema, createQuoteSchema, sendQuoteSmsSchema } from '@shared/validators';
import { validateBody } from '../middleware/validate.js';
import { QuoteRepository } from '../repositories/quote.repository.js';
import { TwilioService } from '../services/twilio.service.js';
import { StripeService } from '../services/stripe.service.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { DispatchService } from '../services/dispatch.service.js';
import { JobRepository } from '../repositories/job.repository.js';

const router = Router();
const repo = new QuoteRepository();
const twilio = new TwilioService();
const stripe = new StripeService();
const dispatch = new DispatchService();
const jobs = new JobRepository();

router.use(requireAuth);
router.get('/', requireRole('owner', 'foreman'), async (_req, res) => res.json(await repo.list()));
router.get('/:id', requireRole('owner', 'foreman'), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  res.json(quote);
});
router.post('/', requireRole('owner', 'foreman'), validateBody(createQuoteSchema), async (req, res) => res.status(201).json(await repo.create(req.body)));
router.post('/:id/send-sms', requireRole('owner', 'foreman'), validateBody(sendQuoteSmsSchema), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  const portalUrl = `${process.env.APP_BASE_URL ?? 'http://localhost:5173'}/portal/quotes/${quote.publicToken}`;
  const body = req.body.message ?? `Your estimate is ready. Review and approve here: ${portalUrl}`;
  const sms = await twilio.sendQuoteLink({ to: req.body.phone, message: req.body.message, portalUrl });
  await repo.markSmsSent(quote.id, req.body.phone);
  await dispatch.recordQuoteSms({
    quoteId: quote.id,
    destinationPhone: req.body.phone,
    body,
    providerMessageId: sms.id ?? null,
    provider: sms.provider
  });
  res.json({ sms, portalUrl });
});
router.post('/:id/payment-link', requireRole('owner', 'foreman'), validateBody(createPaymentLinkSchema), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  const payment = await stripe.createPaymentLink({ quoteId: quote.id, amountCents: quote.totalCents, successUrl: req.body.successUrl, cancelUrl: req.body.cancelUrl });
  await repo.attachPaymentLink(quote.id, payment.url);
  res.json({ payment });
});
router.post('/:id/convert-to-job', requireRole('owner', 'foreman'), async (req, res) => {
  const quote = await repo.getById(req.params.id);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  if (quote.jobId) return res.json({ existing: true, jobId: quote.jobId });

  const serviceAddress = [quote.customer?.addressLine1, quote.customer?.addressLine2, quote.customer?.city, quote.customer?.state, quote.customer?.postalCode]
    .filter(Boolean)
    .join(', ');

  const job = await jobs.createFromApprovedQuote({
    customerId: quote.customerId,
    quoteId: quote.id,
    title: `Approved Quote ${quote.id.slice(0, 8)}`,
    description: quote.notes ?? 'Auto-generated from approved quote.',
    serviceAddress,
    estimatedValueCents: quote.totalCents
  });

  await repo.attachJob(quote.id, job.id);
  res.status(201).json({ job });
});

export default router;
