import { Router } from 'express';
import { assignJobSchema, createJobNoteSchema, createJobPhotoSchema, createJobSchema, dispatchReminderSchema, updateJobStatusSchema, uploadJobPhotoSchema } from '@shared/validators';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { JobRepository } from '../repositories/job.repository.js';
import { StorageService } from '../services/storage.service.js';
import { DispatchService } from '../services/dispatch.service.js';

const router = Router();
const repo = new JobRepository();
const storage = new StorageService();
const dispatch = new DispatchService();

router.use(requireAuth);
router.get('/', async (req, res) => res.json(await repo.list(req.user)));
router.get('/my/queue', requireRole('foreman'), async (req, res) => res.json(await repo.listForemanQueue(req.user!.id)));
router.get('/:id', async (req, res) => {
  const job = await repo.getById(req.params.id, req.user);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});
router.post('/', requireRole('owner'), validateBody(createJobSchema), async (req, res) => res.status(201).json(await repo.create(req.body)));
router.post('/:id/assign', requireRole('owner'), validateBody(assignJobSchema), async (req, res) => {
  const job = await repo.assign(req.params.id, req.body);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});
router.post('/:id/status', requireRole('owner', 'foreman'), validateBody(updateJobStatusSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.json(await repo.updateStatus(req.params.id, req.body));
});
router.post('/:id/notes', requireRole('owner', 'foreman'), validateBody(createJobNoteSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.status(201).json(await repo.addNote(req.params.id, req.user!.id, req.body));
});
router.post('/:id/photos', requireRole('owner', 'foreman'), validateBody(createJobPhotoSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.status(201).json(await repo.addPhoto(req.params.id, req.user!.id, req.body));
});
router.post('/:id/photos/upload', requireRole('owner', 'foreman'), validateBody(uploadJobPhotoSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });

  const stored = await storage.saveBase64Image({
    folder: `jobs/${req.params.id}`,
    filename: req.body.filename,
    mimeType: req.body.mimeType,
    dataBase64: req.body.dataBase64
  });

  const photo = await repo.addPhoto(req.params.id, req.user!.id, {
    imageUrl: stored.url,
    caption: req.body.caption,
    storageKey: stored.storageKey
  });

  res.status(201).json(photo);
});
router.post('/:id/send-reminder', requireRole('owner', 'foreman'), validateBody(dispatchReminderSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });

  const when = req.body.scheduledFor ? new Date(req.body.scheduledFor) : null;
  const defaultMessage = `Reminder: ${current.title} is on the schedule${current.scheduledFor ? ` for ${new Date(current.scheduledFor).toLocaleString()}` : ''}.`;
  if (when && when.getTime() > Date.now() + 60_000) {
    const scheduled = await dispatch.queueJobReminder({
      jobId: req.params.id,
      destinationPhone: req.body.destinationPhone,
      message: req.body.message ?? defaultMessage
    });
    return res.json({ queued: true, scheduled });
  }

  const sms = await dispatch.sendJobReminder({
    jobId: req.params.id,
    destinationPhone: req.body.destinationPhone,
    message: req.body.message ?? defaultMessage
  });
  res.json({ queued: false, sms });
});

export default router;
