import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function DashboardPage() {
  const { user } = useAuth();
  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Operational dashboard</h2>
        <p className="mt-1 text-sm text-slate-500">{user?.role === 'foreman' ? 'Your field queue, updates, notes, and photo capture live here.' : 'Assign jobs, monitor quote progression, and drive field execution.'}</p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Authentication</p><h3 className="mt-2 text-lg font-semibold">Persisted session scaffold</h3><p className="mt-2 text-sm text-slate-600">Cookie-based auth backed by database sessions, with owner and foreman roles ready.</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Field operations</p><h3 className="mt-2 text-lg font-semibold">Notes + photo workflow</h3><p className="mt-2 text-sm text-slate-600">Capture on-site changes fast. Text notes and image URLs are structured for later storage migration.</p></div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm text-slate-500">Queue</p><h3 className="mt-2 text-lg font-semibold">Foreman assignment lane</h3><p className="mt-2 text-sm text-slate-600">Jobs now support assignment and mobile-first field updates.</p></div>
      </div>
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="text-lg font-semibold">Next monetization step</h3>
        <p className="mt-2 text-sm text-slate-600">Phase 4 should wire photo uploads to object storage, convert approvals into scheduled jobs automatically, and trigger SMS reminders before dispatch.</p>
        <div className="mt-4 flex flex-wrap gap-3"><Link to="/jobs" className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-semibold text-white">Open jobs</Link><Link to="/quotes" className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Open quotes</Link></div>
      </div>
    </section>
  );
}
