import { useEffect, useState } from 'react';
import { apiFetch } from '../lib/api';

type Customer = { id: string; firstName: string; lastName: string; email?: string | null; phone: string; city: string; state: string };

export function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  useEffect(() => { apiFetch<Customer[]>('/api/customers').then(setCustomers).catch(console.error); }, []);
  return (
    <section className="space-y-4">
      <h2 className="text-2xl font-bold">Customers</h2>
      <div className="grid gap-4 md:grid-cols-2">
        {customers.length === 0 ? <div className="rounded-2xl border border-slate-200 bg-white p-5">No customers yet.</div> : customers.map((customer) => (
          <article key={customer.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="text-lg font-semibold">{customer.firstName} {customer.lastName}</h3>
            <p className="mt-1 text-sm text-slate-500">{customer.phone}</p>
            <p className="mt-1 text-sm text-slate-500">{customer.email || 'No email'}</p>
            <p className="mt-1 text-sm text-slate-500">{customer.city}, {customer.state}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
