import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function LoginPage() {
  const { user, login, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [fullName, setFullName] = useState('Owner User');
  const [email, setEmail] = useState('owner@example.com');
  const [password, setPassword] = useState('ChangeMe123!');
  const [role, setRole] = useState<'owner' | 'foreman'>('owner');
  const [error, setError] = useState<string | null>(null);

  if (user) return <Navigate to="/" replace />;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      if (mode === 'login') await login({ email, password });
      else await register({ fullName, email, password, role });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Service App</h1>
          <p className="mt-1 text-sm text-slate-500">Real auth, persisted sessions, field workflow.</p>
        </div>
        <div className="mb-6 flex rounded-xl bg-slate-100 p-1 text-sm font-medium">
          <button type="button" onClick={() => setMode('login')} className={`flex-1 rounded-lg px-3 py-2 ${mode === 'login' ? 'bg-white shadow-sm' : 'text-slate-600'}`}>Login</button>
          <button type="button" onClick={() => setMode('register')} className={`flex-1 rounded-lg px-3 py-2 ${mode === 'register' ? 'bg-white shadow-sm' : 'text-slate-600'}`}>Register</button>
        </div>
        <form className="space-y-4" onSubmit={handleSubmit}>
          {mode === 'register' ? (
            <>
              <div>
                <label className="mb-2 block text-sm font-medium">Full name</label>
                <input className="w-full rounded-xl border border-slate-300 px-3 py-2" value={fullName} onChange={(e) => setFullName(e.target.value)} />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium">Role</label>
                <select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={role} onChange={(e) => setRole(e.target.value as 'owner' | 'foreman')}>
                  <option value="owner">Owner</option>
                  <option value="foreman">Foreman</option>
                </select>
              </div>
            </>
          ) : null}
          <div>
            <label className="mb-2 block text-sm font-medium">Email</label>
            <input className="w-full rounded-xl border border-slate-300 px-3 py-2" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Password</label>
            <input type="password" className="w-full rounded-xl border border-slate-300 px-3 py-2" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {error ? <p className="text-sm text-red-600">{error}</p> : null}
          <button type="submit" className="w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white">{mode === 'login' ? 'Login' : 'Create account'}</button>
        </form>
      </div>
    </div>
  );
}
