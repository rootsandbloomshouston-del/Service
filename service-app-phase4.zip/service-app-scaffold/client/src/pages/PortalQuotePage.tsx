import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { apiFetch } from '../lib/api';

type PortalQuote = {
  id: string;
  status: string;
  totalCents: number;
  notes: string | null;
  paymentLinkUrl: string | null;
  customerName?: string;
  lineItems: Array<{
    id: string;
    description: string;
    quantity: string;
    lineTotalCents: number;
  }>;
};

function formatMoney(cents: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(cents / 100);
}

export function PortalQuotePage() {
  const { token } = useParams();
  const [quote, setQuote] = useState<PortalQuote | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function load() {
    if (!token) return;
    const data = await apiFetch<PortalQuote>(`/api/portal/quotes/${token}`);
    setQuote(data);
  }

  useEffect(() => {
    load().catch(console.error);
  }, [token]);

  async function approve() {
    if (!token) return;
    await apiFetch(`/api/portal/quotes/${token}/approve`, { method: 'POST' });
    setMessage('Quote approved.');
    await load();
  }

  if (!quote) {
    return <div className="mx-auto max-w-3xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">Loading quote...</div>;
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div>
        <p className="text-sm font-medium uppercase tracking-wide text-blue-600">Customer portal</p>
        <h1 className="mt-2 text-3xl font-bold">Quote for {quote.customerName ?? 'Customer'}</h1>
        <p className="mt-2 text-slate-500">Status: {quote.status}</p>
      </div>

      <div className="space-y-3 rounded-xl bg-slate-50 p-4">
        {quote.lineItems.map((item) => (
          <div key={item.id} className="flex items-center justify-between gap-4 border-b border-slate-200 pb-3 last:border-b-0 last:pb-0">
            <div>
              <div className="font-medium">{item.description}</div>
              <div className="text-sm text-slate-500">Qty {item.quantity}</div>
            </div>
            <div className="font-semibold">{formatMoney(item.lineTotalCents)}</div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-3">
        <span className="text-sm text-slate-500">Total</span>
        <span className="text-2xl font-bold">{formatMoney(quote.totalCents)}</span>
      </div>

      {quote.notes ? <p className="text-sm text-slate-600">{quote.notes}</p> : null}
      {message ? <p className="rounded-xl bg-green-50 px-4 py-3 text-sm text-green-700">{message}</p> : null}

      <div className="flex flex-col gap-3 sm:flex-row">
        <button className="rounded-xl bg-blue-600 px-4 py-3 font-semibold text-white" onClick={approve}>Approve quote</button>
        {quote.paymentLinkUrl ? (
          <a className="rounded-xl bg-slate-900 px-4 py-3 text-center font-semibold text-white" href={quote.paymentLinkUrl} target="_blank" rel="noreferrer">
            Pay now
          </a>
        ) : null}
      </div>
    </div>
  );
}
