import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import type { JobDetail, JobListItem, JobStatus } from '@shared/types';

type Foreman = { id: string; fullName: string; email: string; role: string };
const statusOptions: JobStatus[] = ['lead', 'quoted', 'approved', 'scheduled', 'in_progress', 'completed', 'cancelled'];
const formatMoney = (cents?: number | null) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format((cents ?? 0) / 100);

export function JobsPage() {
  const { user } = useAuth();
  const [jobs, setJobs] = useState<JobListItem[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<JobDetail | null>(null);
  const [foremen, setForemen] = useState<Foreman[]>([]);
  const [note, setNote] = useState('');
  const [notePhotoUrl, setNotePhotoUrl] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [caption, setCaption] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [reminderPhone, setReminderPhone] = useState('');
  const [reminderMessage, setReminderMessage] = useState('');
  const [error, setError] = useState<string | null>(null);

  const queueEndpoint = user?.role === 'foreman' ? '/api/jobs/my/queue' : '/api/jobs';

  async function loadJobs() {
    const data = await apiFetch<JobListItem[]>(queueEndpoint);
    setJobs(data);
    if (!selectedJobId && data[0]) setSelectedJobId(data[0].id);
  }
  async function loadJob(id: string) { setSelectedJob(await apiFetch<JobDetail>(`/api/jobs/${id}`)); }
  async function loadForemen() { if (user?.role === 'owner') setForemen(await apiFetch<Foreman[]>('/api/auth/foremen')); }

  useEffect(() => { loadJobs().catch(console.error); loadForemen().catch(console.error); }, [queueEndpoint, user?.role]);
  useEffect(() => { if (selectedJobId) loadJob(selectedJobId).catch(console.error); }, [selectedJobId]);

  const selectedSummary = useMemo(() => jobs.find((job) => job.id === selectedJobId) ?? null, [jobs, selectedJobId]);

  async function updateStatus(status: JobStatus) { if (!selectedJob) return; await apiFetch(`/api/jobs/${selectedJob.id}/status`, { method: 'POST', body: JSON.stringify({ status }) }); await loadJobs(); await loadJob(selectedJob.id); }
  async function assignForeman(foremanId: string) { if (!selectedJob) return; await apiFetch(`/api/jobs/${selectedJob.id}/assign`, { method: 'POST', body: JSON.stringify({ assignedForemanUserId: foremanId }) }); await loadJobs(); await loadJob(selectedJob.id); }
  async function addNote() { if (!selectedJob) return; setError(null); try { await apiFetch(`/api/jobs/${selectedJob.id}/notes`, { method: 'POST', body: JSON.stringify({ note, photoUrl: notePhotoUrl }) }); setNote(''); setNotePhotoUrl(''); await loadJob(selectedJob.id); } catch (err) { setError(err instanceof Error ? err.message : 'Failed to add note'); } }
  async function addPhoto() { if (!selectedJob) return; setError(null); try { await apiFetch(`/api/jobs/${selectedJob.id}/photos`, { method: 'POST', body: JSON.stringify({ imageUrl, caption }) }); setImageUrl(''); setCaption(''); await loadJob(selectedJob.id); } catch (err) { setError(err instanceof Error ? err.message : 'Failed to add photo'); } }

  async function uploadPhotoFile() {
    if (!selectedJob || !uploadFile) return;
    const dataBase64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = String(reader.result ?? '');
        resolve(result.includes(',') ? result.split(',')[1] : result);
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(uploadFile);
    });

    await apiFetch(`/api/jobs/${selectedJob.id}/photos/upload`, {
      method: 'POST',
      body: JSON.stringify({
        filename: uploadFile.name,
        mimeType: uploadFile.type || 'image/jpeg',
        dataBase64,
        caption
      })
    });
    setUploadFile(null);
    setCaption('');
    await loadJob(selectedJob.id);
  }

  async function sendReminder() {
    if (!selectedJob || !reminderPhone) return;
    await apiFetch(`/api/jobs/${selectedJob.id}/send-reminder`, {
      method: 'POST',
      body: JSON.stringify({
        destinationPhone: reminderPhone,
        message: reminderMessage || undefined
      })
    });
    setReminderMessage('');
    await loadJob(selectedJob.id);
  }

  return (
    <section className="space-y-6">
      <div><h2 className="text-2xl font-bold">Jobs</h2><p className="mt-1 text-sm text-slate-500">{user?.role === 'foreman' ? 'Your assigned work queue, field notes, and status updates.' : 'Assign foremen, move work through the pipeline, capture photos, and trigger dispatch.'}</p></div>
      <div className="grid gap-6 xl:grid-cols-[340px_minmax(0,1fr)]">
        <div className="space-y-3">{jobs.length === 0 ? <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">No jobs available.</div> : jobs.map((job) => <button key={job.id} type="button" onClick={() => setSelectedJobId(job.id)} className={`w-full rounded-2xl border p-4 text-left shadow-sm ${selectedJobId === job.id ? 'border-blue-600 bg-blue-50' : 'border-slate-200 bg-white'}`}><div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold">{job.title}</h3><p className="mt-1 text-sm text-slate-500">{job.customerName}</p><p className="mt-1 text-sm text-slate-500">{job.serviceAddress}</p></div><span className="rounded-full bg-slate-100 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-700">{job.status.replace('_', ' ')}</span></div></button>)}</div>
        <div className="space-y-6">
          {!selectedJob || !selectedSummary ? <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">Select a job to continue.</div> : <>
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div><h3 className="text-xl font-semibold">{selectedSummary.title}</h3><p className="mt-1 text-sm text-slate-500">{selectedJob.customerName}</p><p className="mt-1 text-sm text-slate-500">{selectedJob.serviceAddress}</p></div>
                <div className="rounded-2xl bg-slate-50 px-4 py-3 text-right"><p className="text-xs uppercase tracking-wide text-slate-500">Estimated value</p><p className="text-lg font-semibold">{formatMoney(selectedSummary.estimatedValueCents)}</p></div>
              </div>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <div><label className="mb-2 block text-sm font-medium text-slate-700">Status</label><select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={selectedJob.status} onChange={(e) => updateStatus(e.target.value as JobStatus).catch(console.error)}>{statusOptions.map((status) => <option key={status} value={status}>{status.replace('_', ' ')}</option>)}</select></div>
                {user?.role === 'owner' ? <div><label className="mb-2 block text-sm font-medium text-slate-700">Assign foreman</label><select className="w-full rounded-xl border border-slate-300 px-3 py-2" value={selectedJob.assignedForemanUserId ?? ''} onChange={(e) => { if (e.target.value) assignForeman(e.target.value).catch(console.error); }}><option value="">Unassigned</option>{foremen.map((foreman) => <option key={foreman.id} value={foreman.id}>{foreman.fullName}</option>)}</select></div> : null}
              </div>
            </div>
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h4 className="text-lg font-semibold">Job notes</h4><div className="mt-4 space-y-3"><textarea className="min-h-28 w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Field update, issue, material note, completion step..." value={note} onChange={(e) => setNote(e.target.value)} /><input className="w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Optional photo URL" value={notePhotoUrl} onChange={(e) => setNotePhotoUrl(e.target.value)} /><button type="button" className="rounded-xl bg-blue-600 px-4 py-2 font-semibold text-white" onClick={() => addNote().catch(console.error)}>Save note</button></div><div className="mt-6 space-y-3">{selectedJob.notes.length === 0 ? <p className="text-sm text-slate-500">No notes yet.</p> : selectedJob.notes.map((item) => <article key={item.id} className="rounded-xl border border-slate-200 p-3"><div className="flex items-start justify-between gap-3"><p className="text-sm font-medium text-slate-800">{item.authorName ?? 'Unknown user'}</p><p className="text-xs text-slate-500">{new Date(item.createdAt).toLocaleString()}</p></div><p className="mt-2 text-sm text-slate-700">{item.note}</p>{item.photoUrl ? <a className="mt-2 inline-block text-sm font-medium text-blue-600" href={item.photoUrl} target="_blank" rel="noreferrer">Open linked photo</a> : null}</article>)}</div></div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h4 className="text-lg font-semibold">Job photos</h4><div className="mt-4 space-y-3"><input className="w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Image URL" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} /><input className="w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Caption" value={caption} onChange={(e) => setCaption(e.target.value)} /><button type="button" className="rounded-xl bg-slate-900 px-4 py-2 font-semibold text-white" onClick={() => addPhoto().catch(console.error)}>Add photo URL</button><div className="rounded-xl border border-dashed border-slate-300 p-3"><label className="mb-2 block text-sm font-medium text-slate-700">Upload photo file</label><input type="file" accept="image/*" onChange={(e) => setUploadFile(e.target.files?.[0] ?? null)} /><button type="button" className="mt-3 rounded-xl bg-emerald-600 px-4 py-2 font-semibold text-white disabled:opacity-50" disabled={!uploadFile} onClick={() => uploadPhotoFile().catch(console.error)}>Upload file</button></div></div><div className="mt-6 grid gap-3 sm:grid-cols-2">{selectedJob.photos.length === 0 ? <p className="text-sm text-slate-500">No photos yet.</p> : selectedJob.photos.map((photo) => <article key={photo.id} className="overflow-hidden rounded-xl border border-slate-200"><img src={photo.imageUrl} alt={photo.caption ?? 'Job photo'} className="h-40 w-full object-cover" /><div className="p-3"><p className="text-sm font-medium text-slate-800">{photo.caption || 'Untitled photo'}</p><p className="mt-1 text-xs text-slate-500">{photo.uploadedByName ?? 'Unknown user'}</p></div></article>)}</div></div>
            </div>
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <h4 className="text-lg font-semibold">Dispatch reminder</h4>
                <div className="mt-4 space-y-3">
                  <input className="w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Customer phone" value={reminderPhone} onChange={(e) => setReminderPhone(e.target.value)} />
                  <textarea className="min-h-24 w-full rounded-xl border border-slate-300 px-3 py-2" placeholder="Optional reminder message" value={reminderMessage} onChange={(e) => setReminderMessage(e.target.value)} />
                  <button type="button" className="rounded-xl bg-violet-600 px-4 py-2 font-semibold text-white" onClick={() => sendReminder().catch(console.error)}>Send reminder</button>
                </div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <h4 className="text-lg font-semibold">Dispatch log</h4>
                <div className="mt-4 space-y-3">
                  {selectedJob.dispatchLogs.length === 0 ? <p className="text-sm text-slate-500">No dispatch activity yet.</p> : selectedJob.dispatchLogs.map((item) => <article key={item.id} className="rounded-xl border border-slate-200 p-3"><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-semibold text-slate-800">{item.dispatchType}</p><p className="text-xs text-slate-500">{item.destination}</p></div><span className="rounded-full bg-slate-100 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-700">{item.status}</span></div><p className="mt-2 text-xs text-slate-500">{new Date(item.createdAt).toLocaleString()}</p></article>)}
                </div>
              </div>
            </div>
            {error ? <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div> : null}
          </>}
        </div>
      </div>
    </section>
  );
}
