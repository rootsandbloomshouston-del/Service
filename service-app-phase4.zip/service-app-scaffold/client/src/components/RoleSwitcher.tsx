import { useEffect, useState } from 'react';

const roles = ['owner', 'foreman', 'customer'] as const;

export function RoleSwitcher() {
  const [role, setRole] = useState('owner');

  useEffect(() => {
    setRole(window.localStorage.getItem('demo-role') ?? 'owner');
  }, []);

  return (
    <label className="flex items-center gap-2 text-sm font-medium text-slate-600">
      Demo role
      <select
        className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
        value={role}
        onChange={(event) => {
          const nextRole = event.target.value;
          setRole(nextRole);
          window.localStorage.setItem('demo-role', nextRole);
          window.location.reload();
        }}
      >
        {roles.map((item) => (
          <option key={item} value={item}>{item}</option>
        ))}
      </select>
    </label>
  );
}
