import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../lib/api';
import type { AuthUser } from '@shared/types';

type LoginInput = { email: string; password: string };
type RegisterInput = { fullName: string; email: string; password: string; role: 'owner' | 'foreman' };

type AuthContextValue = {
  user: AuthUser | null;
  loading: boolean;
  login: (input: LoginInput) => Promise<void>;
  register: (input: RegisterInput) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    const result = await apiFetch<{ user: AuthUser | null }>('/api/auth/me');
    setUser(result.user);
  }

  useEffect(() => {
    refresh().catch(() => setUser(null)).finally(() => setLoading(false));
  }, []);

  async function login(input: LoginInput) {
    const result = await apiFetch<{ user: AuthUser }>('/api/auth/login', { method: 'POST', body: JSON.stringify(input) });
    setUser(result.user);
  }

  async function register(input: RegisterInput) {
    const result = await apiFetch<{ user: AuthUser }>('/api/auth/register', { method: 'POST', body: JSON.stringify(input) });
    setUser(result.user);
  }

  async function logout() {
    await apiFetch<void>('/api/auth/logout', { method: 'POST' });
    setUser(null);
  }

  const value = useMemo(() => ({ user, loading, login, register, logout, refresh }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}
