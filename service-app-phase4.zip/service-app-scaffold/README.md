# Service App Scaffold — Phase 4

Phase 4 pushes the app from internal workflow into dispatchable field operations.

## Added in Phase 4
- Local object-storage style upload flow for job photos
- Static `/uploads` serving for captured field images
- Dispatch log table and repository
- Job reminder SMS workflow
- Quote SMS dispatch logging
- Customer approval to job conversion
- Manual quote-to-job conversion endpoint for back office cleanup

## New database entities / fields
- `dispatch_logs`
- `jobs.source_quote_id`
- `job_photos.storage_key`

## New API surface
### Jobs
- `POST /api/jobs/:id/photos/upload`
- `POST /api/jobs/:id/send-reminder`

### Quotes
- `POST /api/quotes/:id/convert-to-job`

### Portal
- `POST /api/portal/quotes/:token/approve` now auto-creates a job when needed

## Build order
1. Run a migration for `dispatch_logs`, `jobs.source_quote_id`, and `job_photos.storage_key`
2. Ensure `APP_BASE_URL` and Twilio values are set if you want live SMS
3. Start the API so `/uploads` is served
4. Approve a quote in the portal or convert one manually from Quotes page
5. Assign the job, upload field photos, and send reminder SMS

## Constraint
This uses a pragmatic local file-storage pattern for Replit-speed deployment. If you need production-grade scale next, replace `StorageService` with S3 or Supabase Storage without changing the route contract.
