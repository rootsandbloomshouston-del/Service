
import { Request, Response } from "express";

export const stripeWebhook = async (req: Request, res: Response) => {
  console.log("Stripe webhook received");
  res.sendStatus(200);
};
