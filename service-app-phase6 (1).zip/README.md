Phase 6: Calendar sync, Stripe webhooks, invoice delivery
