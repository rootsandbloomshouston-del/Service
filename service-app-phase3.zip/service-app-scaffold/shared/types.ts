export type Role = 'owner' | 'foreman' | 'customer';

export type AuthUser = {
  id: string;
  fullName: string;
  email: string;
  role: Role;
};

export type QuoteListItem = {
  id: string;
  status: string;
  totalCents: number;
  publicToken: string;
  paymentStatus: string;
  smsLastSentAt: string | null;
  customerApproved: boolean;
};

export type JobListItem = {
  id: string;
  title: string;
  status: string;
  serviceAddress: string;
  scheduledFor: string | null;
  estimatedValueCents: number | null;
  assignedForemanUserId: string | null;
  customerName?: string;
};

export type JobNoteItem = {
  id: string;
  note: string;
  photoUrl: string | null;
  createdAt: string;
  authorName: string | null;
};

export type JobPhotoItem = {
  id: string;
  caption: string | null;
  imageUrl: string;
  createdAt: string;
  uploadedByName: string | null;
};

export type JobDetail = JobListItem & {
  description: string | null;
  customerId: string;
  notes: JobNoteItem[];
  photos: JobPhotoItem[];
};

export type JobStatus = 'lead' | 'quoted' | 'approved' | 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
