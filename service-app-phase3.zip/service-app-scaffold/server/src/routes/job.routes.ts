import { Router } from 'express';
import { assignJobSchema, createJobNoteSchema, createJobPhotoSchema, createJobSchema, updateJobStatusSchema } from '@shared/validators';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { JobRepository } from '../repositories/job.repository.js';

const router = Router();
const repo = new JobRepository();

router.use(requireAuth);
router.get('/', async (req, res) => res.json(await repo.list(req.user)));
router.get('/my/queue', requireRole('foreman'), async (req, res) => res.json(await repo.listForemanQueue(req.user!.id)));
router.get('/:id', async (req, res) => {
  const job = await repo.getById(req.params.id, req.user);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});
router.post('/', requireRole('owner'), validateBody(createJobSchema), async (req, res) => res.status(201).json(await repo.create(req.body)));
router.post('/:id/assign', requireRole('owner'), validateBody(assignJobSchema), async (req, res) => {
  const job = await repo.assign(req.params.id, req.body);
  if (!job) return res.status(404).json({ message: 'Job not found' });
  res.json(job);
});
router.post('/:id/status', requireRole('owner', 'foreman'), validateBody(updateJobStatusSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.json(await repo.updateStatus(req.params.id, req.body));
});
router.post('/:id/notes', requireRole('owner', 'foreman'), validateBody(createJobNoteSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.status(201).json(await repo.addNote(req.params.id, req.user!.id, req.body));
});
router.post('/:id/photos', requireRole('owner', 'foreman'), validateBody(createJobPhotoSchema), async (req, res) => {
  const current = await repo.getById(req.params.id, req.user);
  if (!current) return res.status(404).json({ message: 'Job not found' });
  res.status(201).json(await repo.addPhoto(req.params.id, req.user!.id, req.body));
});

export default router;
