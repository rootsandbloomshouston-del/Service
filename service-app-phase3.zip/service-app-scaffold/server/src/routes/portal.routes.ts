import { Router } from 'express';
import { QuoteRepository } from '../repositories/quote.repository.js';

const router = Router();
const repo = new QuoteRepository();

router.get('/quotes/:token', async (req, res) => {
  const quote = await repo.getByPublicToken(req.params.token);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });
  res.json(quote);
});

router.post('/quotes/:token/approve', async (req, res) => {
  const quote = await repo.getByPublicToken(req.params.token);
  if (!quote) return res.status(404).json({ message: 'Quote not found' });

  const approved = await repo.approveByPublicToken(req.params.token);
  res.json({ ok: true, quote: approved });
});

export default router;
