import { and, asc, desc, eq } from 'drizzle-orm';
import { db } from '../db/client.js';
import { customers, jobNotes, jobPhotos, jobs, users, type Job } from '../db/schema.js';
import type { AssignJobInput, CreateJobInput, CreateJobNoteInput, CreateJobPhotoInput, UpdateJobStatusInput } from '@shared/validators';

export class JobRepository {
  async list(currentUser?: { id: string; role: string }) {
    const baseQuery = db.select({
      id: jobs.id,
      customerId: jobs.customerId,
      title: jobs.title,
      status: jobs.status,
      serviceAddress: jobs.serviceAddress,
      scheduledFor: jobs.scheduledFor,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      customerName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs).innerJoin(customers, eq(customers.id, jobs.customerId));

    const rows = currentUser?.role === 'foreman'
      ? await baseQuery.where(eq(jobs.assignedForemanUserId, currentUser.id)).orderBy(desc(jobs.createdAt))
      : await baseQuery.orderBy(desc(jobs.createdAt));

    return rows.map((row) => ({
      id: row.id,
      customerId: row.customerId,
      title: row.title,
      status: row.status,
      serviceAddress: row.serviceAddress,
      scheduledFor: row.scheduledFor,
      estimatedValueCents: row.estimatedValueCents,
      assignedForemanUserId: row.assignedForemanUserId,
      customerName: `${row.customerName} ${row.customerLastName}`
    }));
  }

  async getById(id: string, currentUser?: { id: string; role: string }) {
    const filters = [eq(jobs.id, id)];
    if (currentUser?.role === 'foreman') filters.push(eq(jobs.assignedForemanUserId, currentUser.id));

    const [job] = await db.select({
      id: jobs.id,
      customerId: jobs.customerId,
      title: jobs.title,
      description: jobs.description,
      serviceAddress: jobs.serviceAddress,
      status: jobs.status,
      scheduledFor: jobs.scheduledFor,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      customerName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs).innerJoin(customers, eq(customers.id, jobs.customerId)).where(and(...filters));

    if (!job) return undefined;

    const notes = await db.select({
      id: jobNotes.id,
      note: jobNotes.note,
      photoUrl: jobNotes.photoUrl,
      createdAt: jobNotes.createdAt,
      authorName: users.fullName
    }).from(jobNotes).leftJoin(users, eq(users.id, jobNotes.authorUserId)).where(eq(jobNotes.jobId, id)).orderBy(desc(jobNotes.createdAt));

    const photos = await db.select({
      id: jobPhotos.id,
      imageUrl: jobPhotos.imageUrl,
      caption: jobPhotos.caption,
      createdAt: jobPhotos.createdAt,
      uploadedByName: users.fullName
    }).from(jobPhotos).leftJoin(users, eq(users.id, jobPhotos.uploadedByUserId)).where(eq(jobPhotos.jobId, id)).orderBy(desc(jobPhotos.createdAt));

    return {
      id: job.id,
      customerId: job.customerId,
      title: job.title,
      description: job.description,
      status: job.status,
      serviceAddress: job.serviceAddress,
      scheduledFor: job.scheduledFor,
      estimatedValueCents: job.estimatedValueCents,
      assignedForemanUserId: job.assignedForemanUserId,
      customerName: `${job.customerName} ${job.customerLastName}`,
      notes,
      photos
    };
  }

  async create(input: CreateJobInput): Promise<Job> {
    const [job] = await db.insert(jobs).values({
      customerId: input.customerId,
      assignedForemanUserId: input.assignedForemanUserId ?? null,
      title: input.title,
      description: input.description || null,
      serviceAddress: input.serviceAddress,
      status: input.status,
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : null,
      estimatedValueCents: input.estimatedValueCents ?? null
    }).returning();
    return job;
  }

  async assign(jobId: string, input: AssignJobInput) {
    const [job] = await db.update(jobs).set({ assignedForemanUserId: input.assignedForemanUserId, updatedAt: new Date() }).where(eq(jobs.id, jobId)).returning();
    return job;
  }

  async updateStatus(jobId: string, input: UpdateJobStatusInput) {
    const [job] = await db.update(jobs).set({
      status: input.status,
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : undefined,
      updatedAt: new Date()
    }).where(eq(jobs.id, jobId)).returning();
    return job;
  }

  async addNote(jobId: string, authorUserId: string, input: CreateJobNoteInput) {
    const [note] = await db.insert(jobNotes).values({ jobId, authorUserId, note: input.note, photoUrl: input.photoUrl || null }).returning();
    return note;
  }

  async addPhoto(jobId: string, uploadedByUserId: string, input: CreateJobPhotoInput) {
    const [photo] = await db.insert(jobPhotos).values({ jobId, uploadedByUserId, imageUrl: input.imageUrl, caption: input.caption || null }).returning();
    return photo;
  }

  async listForemanQueue(foremanUserId: string) {
    return db.select({
      id: jobs.id,
      title: jobs.title,
      status: jobs.status,
      serviceAddress: jobs.serviceAddress,
      scheduledFor: jobs.scheduledFor,
      estimatedValueCents: jobs.estimatedValueCents,
      assignedForemanUserId: jobs.assignedForemanUserId,
      customerName: customers.firstName,
      customerLastName: customers.lastName
    }).from(jobs).innerJoin(customers, eq(customers.id, jobs.customerId)).where(eq(jobs.assignedForemanUserId, foremanUserId)).orderBy(asc(jobs.scheduledFor), desc(jobs.createdAt));
  }
}
