# Service App Scaffold — Phase 3

Phase 3 hardens the app from demo flow into an operational system.

## Added in Phase 3
- Real email/password auth using hashed passwords
- Persisted database-backed sessions with secure HTTP-only cookie pattern
- Owner and foreman roles enforced on server routes
- Job assignment to foremen
- Mobile-first foreman queue route
- Job notes and job photos workflow
- Seed script for initial owner account

## New database entities
- `auth_sessions`
- `job_photos`
- `jobs.assigned_foreman_user_id`

## New API surface
### Auth
- `GET /api/auth/me`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/foremen`

### Jobs
- `GET /api/jobs`
- `GET /api/jobs/my/queue`
- `GET /api/jobs/:id`
- `POST /api/jobs`
- `POST /api/jobs/:id/assign`
- `POST /api/jobs/:id/status`
- `POST /api/jobs/:id/notes`
- `POST /api/jobs/:id/photos`

## Build order to activate this scaffold
1. Run DB migration for `auth_sessions`, `job_photos`, and updated `jobs`
2. Seed first owner with `npm run seed:owner`
3. Log in through `/login`
4. Create foreman accounts
5. Assign jobs from owner dashboard
6. Use foreman queue to update status, notes, and photos

## Important constraint
Photo capture is scaffolded as `imageUrl` entry, not multipart file upload yet. That is intentional. Object storage belongs in Phase 4.
